package Model;

import java.util.ArrayList;
public class Utente {
    private String nome;
    private String cognome;
    private String nickname;
    private String password;
    private GalleriaPersonale galleriaPersonale;
    private ArrayList<GalleriaCondivisa> gallerieACuiPartecipa = new ArrayList<>();

    public Utente(String n){
        nickname=n;
    }
    public String getNicknameUtente(){return nickname;}
    public void setPasswordUtente(String p){password=p;}
    public String getPasswordUtente(){return password;}
    public void setNomeUtente(String n){nome=n;}
    public String getNomeUtente(){return nome;}
    public void setCognomeUtente (String c){cognome=c;}
    public String getCognomeUtente(){return cognome;}
    public Integer getCodGP(){return galleriaPersonale.idGalleria;}
    public void addGalleriaACuiPartecipa(GalleriaCondivisa GC){
        gallerieACuiPartecipa.add(GC);}
    public void setGalleriaPersonale(GalleriaPersonale GP){
        galleriaPersonale=GP;}
}
