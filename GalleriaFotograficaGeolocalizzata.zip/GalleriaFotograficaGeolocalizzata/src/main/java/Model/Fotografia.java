package Model;

import java.lang.reflect.Array;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class Fotografia {
    private Integer idfoto;
    private String nome;
    private String dispositivo;
    private Boolean visibilita;
    private Integer larghezza;
    private Integer altezza;
    private Date data;
    private Utente fotografo;
    private Luogo luogoScatto;
    private ArrayList<Soggetto> soggettiPartecipanti = new ArrayList<Soggetto>();
    private ArrayList<GalleriaCondivisa> galleriaInCuiEContenuta = new ArrayList<>();

    public Fotografia(Integer idf, String n, String d, Boolean v, Luogo l, Utente f, Soggetto s, GalleriaPersonale g){
        idfoto=idf;
        nome=n;
        dispositivo=d;
        visibilita=v;
        luogoScatto=l;
        fotografo=f;

        soggettiPartecipanti.add(s);
        s.addFotografiaRappresentata(this);

        f.setGalleriaPersonale(g);
        g.addFotoInGalleria(this);

    }
    public void setIdfoto(Integer idf){idfoto=idf;}
    public Integer getIdFoto(){return idfoto;}
    public String getNomeFotografia(){
        return nome;
    }
    public String getDispositivoFotografia(){
        return dispositivo;
    }
    public void setVisibilita(Boolean v){visibilita=v;}
    public String getVisibilitaFotografia(){
        if (visibilita)
            return "pubblico";
        else
            return "privato";
    }
    public void setDataScatto(Date d){
        data=d;
    }
    public Date getDataScatto(){
        return data;
    }
    public void setDimensioni(Integer l, Integer a){
        larghezza=l;
        altezza=a;
    }
    public String getDimensioniFotografia(){return larghezza+"x"+altezza;}
    public Integer getAltezzaFotografia(){return altezza;}
    public Integer getLarghezzaFotografia(){return larghezza;}
    public String getFotografo(){return fotografo.getNicknameUtente();}
    public void setLuogoScattoFotografia(Luogo luogo){luogoScatto=luogo;}
    public Luogo getLuogoScattoFotografia(){return luogoScatto;}
    public void addSoggettoPartecipante(Soggetto s){soggettiPartecipanti.add(s);}
    public String getElencoSoggettiFotografia(){
        String elencoSoggetti;
        Integer i=1;
        if (soggettiPartecipanti.get(0).getTipoSoggetto().equals("utente"))
            elencoSoggetti=soggettiPartecipanti.get(0).getUtente().getNicknameUtente();
        else if (soggettiPartecipanti.get(0).getTipoSoggetto().equals("luogo"))
            elencoSoggetti=soggettiPartecipanti.get(0).getLuogo().getNomeLuogo();
        else
            elencoSoggetti=soggettiPartecipanti.get(0).getTipoSoggetto();
        while (i<soggettiPartecipanti.size()){
            if (soggettiPartecipanti.get(i).getTipoSoggetto().equals("utente"))
                elencoSoggetti=elencoSoggetti+", "+soggettiPartecipanti.get(i).getUtente().getNicknameUtente();
            else if (soggettiPartecipanti.get(i).getTipoSoggetto().equals("luogo"))
                elencoSoggetti=elencoSoggetti+", "+soggettiPartecipanti.get(i).getLuogo().getCoordinateFotografia(this);
            else
                elencoSoggetti=elencoSoggetti+", "+soggettiPartecipanti.get(i).getTipoSoggetto();
            i++;
        }
        return elencoSoggetti;
    }
    public void addGalleriaInCuiEContenuta(GalleriaCondivisa GC){galleriaInCuiEContenuta.add(GC);}

    public Fotografia(String n, String d, Boolean v, Utente f) {
        nome=n;
        dispositivo=d;
        visibilita=v;
        fotografo=f;
    }
}
