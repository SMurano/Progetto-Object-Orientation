package Model;

import java.util.ArrayList;

public class Soggetto {
    private String tipo;
    private Integer codiceSoggetto;
    private Utente tipoUtente;
    private Luogo tipoLuogo;
    private ArrayList<Fotografia> fotografieRappresentanti = new ArrayList<>();
    public Soggetto(String t,Fotografia f){
        tipo=t;
        fotografieRappresentanti.add(f);
        f.addSoggettoPartecipante(this);
    }
    public Soggetto(Utente u,Fotografia f){
        tipo="utente";
        tipoUtente=u;
        fotografieRappresentanti.add(f);
        f.addSoggettoPartecipante(this);
    }
    public Soggetto(Luogo l,Fotografia f){
        tipo="luogo";
        tipoLuogo=l;
        fotografieRappresentanti.add(f);
        f.addSoggettoPartecipante(this);
    }

    public void setCodiceSoggetto(Integer codSogetto){
        codiceSoggetto=codSogetto;
    }

    public Utente getUtente(){return tipoUtente;}

    public Luogo getLuogo(){return tipoLuogo;}
    public String getTipoSoggetto(){
        return tipo;
    }
    public void addFotografiaRappresentata(Fotografia f){fotografieRappresentanti.add(f);}
}
