package Model;

import java.util.ArrayList;

public class GalleriaCondivisa extends Galleria {
    private ArrayList<Utente> utentiPartecipanti = new ArrayList<>();
    private ArrayList<Fotografia> fotoGalleria = new ArrayList<>();
    public GalleriaCondivisa(String nome, Utente u1,Utente u2){
        super(nome);

        utentiPartecipanti.add(u1);
        u1.addGalleriaACuiPartecipa(this);

        utentiPartecipanti.add(u2);
        u2.addGalleriaACuiPartecipa(this);

    }
    public void addFotoInGalleria(Fotografia f){
        fotoGalleria.add(f);
        f.addGalleriaInCuiEContenuta(this);}

    public Fotografia getFotoDaGalleria(Integer i){
        return fotoGalleria.get(i);
    }
    public Integer getPosizioneFoto(Fotografia f){
        return fotoGalleria.indexOf(f);
    }
    public void setUtentiPartecipanti(ArrayList<Utente> utenti){
        utentiPartecipanti=utenti;
    }
    public ArrayList<String> getNicknamesUtentiPartecipanti(){
        ArrayList<String> nicknames= new ArrayList<>();
        Integer i=0;
        while (i<utentiPartecipanti.size()) {
            nicknames.add(utentiPartecipanti.get(i).getNicknameUtente());
            i++;
        }
        return nicknames;
    }
}
