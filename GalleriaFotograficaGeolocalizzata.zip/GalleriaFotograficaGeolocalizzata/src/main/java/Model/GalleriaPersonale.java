package Model;

import java.util.ArrayList;

public class GalleriaPersonale extends Galleria{
    private Utente utente;
    private ArrayList<Fotografia> fotoGalleria= new ArrayList<Fotografia>();
    public GalleriaPersonale(String nome, Utente u){
        super(nome);
        utente=u;
        u.setGalleriaPersonale(this);
    }
}
