package Model;

import java.util.ArrayList;

public class Luogo {
    private double latitudine;
    private double longitudine;
    private String nome;
    private ArrayList<Fotografia>fotografieLocalizzate = new ArrayList<Fotografia>();

    public Luogo(String nomeLuogo, Double lat,Double lon,Fotografia f){
       nome=nomeLuogo;
       latitudine=lat;
       longitudine=lon;
       f.setLuogoScattoFotografia(this);
       fotografieLocalizzate.add(f);
    }
    public Luogo(String nomeLuogo,Fotografia f){
        nome=nomeLuogo;
        f.setLuogoScattoFotografia(this);
        fotografieLocalizzate.add(f);
    }
    public Luogo(String nomeLuogo){
        nome=nomeLuogo;
    }
    public void setNomeLuogo(String n){nome=n;}
    public String getNomeLuogo(){return nome;}
    public String getCoordinateFotografia(Fotografia f){
        return (f.getLuogoScattoFotografia().getNomeLuogo() + ": " + latitudine + "x" + longitudine);
    }
    public void setCoordinate(Double lat, Double lon){
        latitudine=lat;
        longitudine=lon;
    }
}
