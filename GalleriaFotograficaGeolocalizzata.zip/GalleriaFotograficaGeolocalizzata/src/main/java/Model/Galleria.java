package Model;

import java.util.ArrayList;

public class Galleria {
    protected Integer idGalleria;
    protected String nomeGalleria;

    protected ArrayList<Fotografia> fotoGalleria= new ArrayList<Fotografia>();
    public void setIdGalleria(Integer id){idGalleria=id;}
    public String getNomeGalleria(){
        return nomeGalleria;
    }
    public void addFotoInGalleria(Fotografia f){
        fotoGalleria.add(f);
    }
    public Fotografia getFotoDaGalleria(Integer i){
        return fotoGalleria.get(i);
    }
    public Integer getPosizioneFoto(Fotografia f){
        return fotoGalleria.indexOf(f);
    }
    public Integer getNumeroFoto(){return fotoGalleria.size();}
    public void deleteFotografia(Fotografia f){
        fotoGalleria.remove(f);
    }



    public Galleria(String nome){
        nomeGalleria=nome;
    }
    
}
