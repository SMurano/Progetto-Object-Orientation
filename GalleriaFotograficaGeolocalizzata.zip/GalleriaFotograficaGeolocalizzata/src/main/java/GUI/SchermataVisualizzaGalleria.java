package GUI;

import Controller.Controller;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.filechooser.FileSystemView;
import java.awt.event.*;

public class SchermataVisualizzaGalleria {
    private JPanel GalleriaVisualizzata;
    private JLabel SchermataVisualizzaGalleriaNomeGalleriaLabel;
    private JLabel SchermataVisualizzaGalleriaMembriGalleriaLabel;
    private JScrollBar SchermataVisualizzaGalleriascrollBar1;
    private JButton SchermataVisualizzaGalleriaReturnHomeVisioneGalleriaButton;
    private JButton SchermataVisualizzaGalleriaAggiungiFoto;
    private JLabel SchermataVisualizzaGalleria1Label;
    private JLabel SchermataVisualizzaGalleria2Label;
    private JLabel SchermataVisualizzaGalleria3Label;
    private JScrollBar SchermataVisualizzaGalleriaScrollBar;


    public SchermataVisualizzaGalleria(Controller controller, JFrame schermataUtente, JFrame schermataLogin) {
        JFrame frame = new JFrame("GalleriaVisualizzata");
        frame.setContentPane(GalleriaVisualizzata);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

//APPENA ENTRATO NELLA SCHERMATA DI VISUALIZZAZIONE DELLA GALLERIA
        //imposto il nome della galleria visualizzata
        SchermataVisualizzaGalleriaNomeGalleriaLabel.setText(SchermataVisualizzaGalleriaNomeGalleriaLabel.getText() + " " + controller.getGalleriaVisualizzata());

        //visualizzo le fotografie contenute nella galleria
        //se sono più di 3 attivo la scrollbar in modo da poterle visualizzare tutte
        try {
            if (controller.getNumeroFotoGalleriaVisualizzata()>3) {
                SchermataVisualizzaGalleriaScrollBar.setVisible(true);
                SchermataVisualizzaGalleriaScrollBar.setValues(0, 1, 0, (controller.getNumeroFotoGalleriaVisualizzata() - 2));
            }
            controller.recuperoGalleriaCondivisaDB(controller.getNicknameUtenteLoggato());
            SchermataVisualizzaGalleriaMembriGalleriaLabel.setText(SchermataVisualizzaGalleriaMembriGalleriaLabel.getText()+controller.getNicknamesUtentiPartecipantiGalleriaVisualizzata());

            SchermataVisualizzaGalleria1Label.setIcon(controller.aggiungiFotoAllaGalleriaCondivisa(0, 500, 400));
            SchermataVisualizzaGalleria2Label.setIcon(controller.aggiungiFotoAllaGalleriaCondivisa(1, 500, 400));
            SchermataVisualizzaGalleria3Label.setIcon(controller.aggiungiFotoAllaGalleriaCondivisa(2, 500, 400));
        } catch (NullPointerException e){
        }
        frame.pack();

//PASSAGGIO ALL'INSERIMENTO DI UNA FOTOGRAFIA NELLA GALLERIA VISUALIZZATA
        SchermataVisualizzaGalleriaAggiungiFoto.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setAcceptAllFileFilterUsed(false);
                fileChooser.setCurrentDirectory(FileSystemView.getFileSystemView().getHomeDirectory().getAbsoluteFile());
                fileChooser.addChoosableFileFilter(new FileNameExtensionFilter("Immagini","jpg","png"));
                if (fileChooser.showOpenDialog(null)==JFileChooser.APPROVE_OPTION) {
                    controller.setPercorsoFotografiaVisualizzata(fileChooser.getSelectedFile().getAbsolutePath());
                    SchermataInserimentoFoto schermataInserimentoFoto = new SchermataInserimentoFoto(controller, frame, schermataLogin);
                    frame.setVisible(false);
                    frame.dispose();
                    frame.pack();
                }
            }
        });

//PASSAGGIO ALLA VISUALIZZAZIONE DI UNA FOTOGRAFIA
        SchermataVisualizzaGalleria1Label.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                controller.setFotografiaVisualizzata(controller.getFotoGalleriaCondivisaVisualizzata(SchermataVisualizzaGalleriaScrollBar.getValue()));
                SchermataVisualizzazioneFotografia schermataVisualizzazioneFotografia = new SchermataVisualizzazioneFotografia(controller, frame, schermataLogin, controller.getFotografiaVisualizzata());
                frame.setVisible(false);
                frame.dispose();
            }
        });
        SchermataVisualizzaGalleria2Label.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                controller.setFotografiaVisualizzata(controller.getFotoGalleriaCondivisaVisualizzata(SchermataVisualizzaGalleriaScrollBar.getValue()+1));
                SchermataVisualizzazioneFotografia schermataVisualizzazioneFotografia = new SchermataVisualizzazioneFotografia(controller, frame, schermataLogin, controller.getFotografiaVisualizzata());
                frame.setVisible(false);
                frame.dispose();
            }
        });
        SchermataVisualizzaGalleria3Label.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                controller.setFotografiaVisualizzata(controller.getFotoGalleriaCondivisaVisualizzata(SchermataVisualizzaGalleriaScrollBar.getValue()+2));
                SchermataVisualizzazioneFotografia schermataVisualizzazioneFotografia = new SchermataVisualizzazioneFotografia(controller, frame, schermataLogin, controller.getFotografiaVisualizzata());
                frame.setVisible(false);
                frame.dispose();
            }
        });

        SchermataVisualizzaGalleriaScrollBar.addAdjustmentListener(new AdjustmentListener() {
            @Override
            public void adjustmentValueChanged(AdjustmentEvent e) {
                SchermataVisualizzaGalleria1Label.setIcon(controller.aggiungiFotoAllaGalleriaCondivisa(SchermataVisualizzaGalleriaScrollBar.getValue(), 500, 400));
                SchermataVisualizzaGalleria2Label.setIcon(controller.aggiungiFotoAllaGalleriaCondivisa((SchermataVisualizzaGalleriaScrollBar.getValue()+1), 500, 400));
                SchermataVisualizzaGalleria3Label.setIcon(controller.aggiungiFotoAllaGalleriaCondivisa((SchermataVisualizzaGalleriaScrollBar.getValue()+2), 500, 400));

            }
        });

//RITORNO ALLA SCHERMATA UTENTE
        SchermataVisualizzaGalleriaReturnHomeVisioneGalleriaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                schermataUtente.setVisible(true);
                frame.setVisible(false);
                frame.dispose();
            }
        });
    }
}
