package GUI;

import Controller.Controller;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Arrays;

public class SchermataCreazioneGalleriaCondivisa {
    public JFrame frame;
    private JLabel CreazioneGalleriaCondivisaTitoloLabel;
    private JLabel CreazioneGalleriaCondivisaNomeLabel;
    private JTextField CreazioneGalleriaCondivisaNomeTextBox;
    private JLabel CreazioneGalleriaCondivisaPartecipantiLabel;
    private JTextField CreazioneGalleriaCondivisaPartecipantiTextBox;
    private JLabel CreazioneGalleriaCondivisaElencoPartecipantiLabel;
    private JTextField CreazioneGalleriaCondivisaElencoPartecipantiTextBox;
    private JButton CreazioneGalleriaCondivisaCreaButton;
    private JPanel CreazioneGalleriaCondivisa;
    private JButton CreazioneGalleriaCondivisaAnnullaButton;

    public SchermataCreazioneGalleriaCondivisa(Controller controller, JFrame schermataUtente) {

        JFrame frame = new JFrame("CreazioneGalleriaCondivisa");
        frame.setContentPane(CreazioneGalleriaCondivisa);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
        CreazioneGalleriaCondivisaElencoPartecipantiTextBox.setText(controller.getNicknameUtenteLoggato());

        CreazioneGalleriaCondivisaPartecipantiTextBox.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                super.keyPressed(e);
                if (e.getKeyCode()==KeyEvent.VK_ENTER){
                    if (!(CreazioneGalleriaCondivisaElencoPartecipantiTextBox.getText().equals(CreazioneGalleriaCondivisaPartecipantiTextBox.getText()) || CreazioneGalleriaCondivisaElencoPartecipantiTextBox.getText().contains(", " + CreazioneGalleriaCondivisaPartecipantiTextBox.getText() + ",") || CreazioneGalleriaCondivisaElencoPartecipantiTextBox.getText().contains(", " + CreazioneGalleriaCondivisaPartecipantiTextBox.getText())))
                        if (controller.controlloEsistenzaUtenteDB(CreazioneGalleriaCondivisaPartecipantiTextBox.getText()))
                            if (CreazioneGalleriaCondivisaElencoPartecipantiTextBox.getText().isBlank())
                                CreazioneGalleriaCondivisaElencoPartecipantiTextBox.setText(CreazioneGalleriaCondivisaPartecipantiTextBox.getText());
                            else
                                CreazioneGalleriaCondivisaElencoPartecipantiTextBox.setText(CreazioneGalleriaCondivisaElencoPartecipantiTextBox.getText() + ", " + CreazioneGalleriaCondivisaPartecipantiTextBox.getText());
                    CreazioneGalleriaCondivisaPartecipantiTextBox.setText("");
                }
            }
        });

        CreazioneGalleriaCondivisaCreaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (CreazioneGalleriaCondivisaNomeTextBox.getText().isBlank()|| !CreazioneGalleriaCondivisaNomeTextBox.getText().matches("^[a-zA-Z0-9_ ]*$")){
                    JOptionPane.showMessageDialog(null, "Inserisci un nome valido per la galleria (Max 30 caratteri alfanumerici o underscore)");
                    return;
                }

                if (CreazioneGalleriaCondivisaElencoPartecipantiTextBox.getText().equals(controller.getNicknameUtenteLoggato()))
                    JOptionPane.showMessageDialog(null, "Inserisci almeno un partecipante");
                else {
                    ArrayList<String> utentiPartecipanti = new ArrayList<>(Arrays.asList(CreazioneGalleriaCondivisaElencoPartecipantiTextBox.getText().split("\\s*,\\s*")));
                    controller.creaGalleriaCondivisaDB(CreazioneGalleriaCondivisaNomeTextBox.getText(),utentiPartecipanti);
                    controller.addGalleriaCondivisa();
                    schermataUtente.setVisible(true);
                    frame.setVisible(false);
                    frame.dispose();
                }
            }
        });

        CreazioneGalleriaCondivisaAnnullaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                schermataUtente.setVisible(true);
                frame.setVisible(false);
                frame.dispose();
            }
        });
    }
}
