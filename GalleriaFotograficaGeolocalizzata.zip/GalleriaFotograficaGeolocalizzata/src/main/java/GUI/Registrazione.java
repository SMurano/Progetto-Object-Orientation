package GUI;

import Controller.Controller;
import org.postgresql.util.PSQLException;

import javax.naming.ldap.Control;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class Registrazione {

    public JFrame frame;
    private JPanel SchermataRegistrazione;
    private JLabel RegisterLabel;
    private JLabel RegisterNamelabel;
    private JTextField RegisterNameTextBox;
    private JLabel RegisterLnameLabel;
    private JTextField RegisterLnameTextBox;
    private JLabel RegisterUsernameLabel;
    private JTextField RegisterUsernameTextBox;
    private JLabel RegisterPasswordLabel;
    private JPasswordField RegisterPasswordTextBox;
    private JLabel RegisterConfirmPasswordLabel;
    private JPasswordField RegisterConfirmPasswordTextBox;
    private JButton RegisterConfirmButton;
    private JButton RegisterAnnullaButton;


    public Registrazione(Controller controller, JFrame SchermataLogin) {

        JFrame frame =new JFrame("Registrazione");
        frame.setContentPane(SchermataRegistrazione);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);

//GESTIONE DELLA REGISTRAZIONE DELL'UTENTE
        RegisterConfirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                 //controllo che username e password dell'utente siano validi
                 if (RegisterUsernameTextBox.getText().isBlank() || !RegisterUsernameTextBox.getText().matches("^[a-zA-Z0-9_# ]*$") || RegisterUsernameTextBox.getText().length()>30) {
                     JOptionPane.showMessageDialog(null, "Inserisci un nome utente valido (Max 30 caratteri alfanumerici, underscore o hashtag)");
                     return;
                 };
                if(RegisterPasswordTextBox.getPassword().length==0 || !String.valueOf(RegisterPasswordTextBox.getPassword()).matches("^[a-zA-Z0-9_# ]*$") || String.valueOf(RegisterPasswordTextBox.getPassword()).length()>30) {
                    JOptionPane.showMessageDialog(null, "Inserisci una password valida (Max 30 caratteri alfanumerici, underscore o hashtag)");
                    return;
                }
                if(!String.valueOf(RegisterPasswordTextBox.getPassword()).equals(String.valueOf(RegisterConfirmPasswordTextBox.getPassword()))) {
                    JOptionPane.showMessageDialog(null, "La password non corrisponde a quella inserita");
                    return;
                }

                //se l'username e la password sono valide instanzio l'utente corrente come utente loggato
                controller.createUtenteLoggato(RegisterUsernameTextBox.getText());
                controller.setPasswordUtenteLoggato(String.valueOf(RegisterPasswordTextBox.getPassword()));

                //controllo che nome e cognome dell'utente siano validi, se lo sono li aggiungo come attributi all'utente loggato
                if (!RegisterNameTextBox.getText().isBlank())
                    if (RegisterNameTextBox.getText().matches("^[a-zA-Z ]*$") && RegisterNameTextBox.getText().length()<=30)
                        controller.setNameUtenteLoggato(RegisterNameTextBox.getText());
                    else {
                        JOptionPane.showMessageDialog(null, "Nome non valido (Max 30 caratteri alfabetici)");
                        return;
                    }
                if(!RegisterLnameTextBox.getText().isBlank())
                    if (RegisterLnameTextBox.getText().matches("^[a-zA-Z ]*$") && RegisterLnameTextBox.getText().length()<=30)
                        controller.setLNameUtenteLoggato(RegisterLnameTextBox.getText());
                    else {
                        JOptionPane.showMessageDialog(null, "Cognome non valido (Max 30 caratteri alfabetici)");
                        return;
                    }

                //se tutti i dati inseriti sono validi procedo alla registrazione dell'utente (se il nome utente è già presente nel database verrà segnalato e si dovrà riporcedere alla registrazione)
                if(controller.registrazioneUtenteDB()){
                    SchermataLogin.setVisible(true);
                    frame.setVisible(false);
                    frame.dispose();
                }
            }
        });

//RITORNO ALLA SCHERMATA DI LOGIN SENZA EFFETTUARE LA REGISTRAZIONE
        RegisterAnnullaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SchermataLogin.setVisible(true);
                frame.setVisible(false);
                frame.dispose();
            }
        });
    }
}
