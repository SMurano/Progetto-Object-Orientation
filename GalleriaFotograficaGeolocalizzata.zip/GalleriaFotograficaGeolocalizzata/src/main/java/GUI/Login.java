package GUI;

import Controller.Controller;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

public class Login {
    public Controller controller;
    private static JFrame frame;
    private JPanel SchermataLogin;
    private JLabel LoginLabel;
    private JTextField LoginUsernameTextbox;
    private JButton LoginConfirmButton;
    private JLabel LoginUsernameLabel;
    private JLabel LoginPasswordLabel;
    private JPasswordField LoginPasswordTextBox;
    private JButton LoginRegisterButton;
    public Login(){
        controller = new Controller();

//PASSAGGIO ALLA SCHERMATA DI REGISTRAZIONE
        LoginRegisterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Registrazione registrazione=new Registrazione(controller,frame);
                LoginUsernameTextbox.setText(null);
                LoginPasswordTextBox.setText(null);
                frame.setVisible(false);
                frame.dispose();

            }
        });

        LoginConfirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                 //controllo che l'utente abbia inserito username e password
                 if (LoginUsernameTextbox.getText().isBlank()) {
                     JOptionPane.showMessageDialog(null,"Inserisci il tuo nickname");
                     return;
                 }

                 if (LoginPasswordTextBox.getPassword().length==0) {
                     JOptionPane.showMessageDialog(null,"Password non valida");
                     return;
                 }

                 //controllo che esista un utente con le credenziali inserite
                 if(controller.controlloEsistenzaUtenteLoggatoDB(LoginUsernameTextbox.getText(),String.valueOf(LoginPasswordTextBox.getPassword()))) {

                     //se l'utente esiste lo istanzio come utente loggato e creo la sua galleria
                     controller.createUtenteLoggato(LoginUsernameTextbox.getText());
                     controller.createGalleriaUtenteLoggato("GALLERIA DI "+controller.getNicknameUtenteLoggato());
                     controller.setGalleriaVisualizzata(controller.getNomeGalleriaPersonale());

                     //se l'utente esiste recupero le gallerie a cui partecipa e le sue fotografie
                     controller.getGallerieACuiPartecipi();
                     controller.getFotografieUtente();
                     LoginUsernameTextbox.setText(null);
                     LoginPasswordTextBox.setText(null);
                     SchermataUtente schermataUtente = new SchermataUtente(controller, frame, frame);
                     frame.setVisible(false);
                     frame.dispose();
                 }
            }
        });
    }

    public static void main(String[] args){
        frame = new JFrame("Login");
        frame.setContentPane(new Login().SchermataLogin);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
