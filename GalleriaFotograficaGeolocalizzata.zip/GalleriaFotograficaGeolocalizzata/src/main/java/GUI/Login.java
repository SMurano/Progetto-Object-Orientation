package GUI;

import Controller.Controller;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

public class Login {
    public Controller controller;
    private static JFrame frame;
    private JPanel SchermataLogin;
    private JLabel LoginLabel;
    private JTextField LoginUsernameTextbox;
    private JButton LoginConfirmButton;
    private JLabel LoginUsernameLabel;
    private JLabel LoginPasswordLabel;
    private JPasswordField LoginPasswordTextBox;
    private JButton LoginRegisterButton;
    public Login(){
        controller = new Controller();

        LoginRegisterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Registrazione registrazione=new Registrazione(controller,frame);
                LoginUsernameTextbox.setText(null);
                LoginPasswordTextBox.setText(null);
                frame.setVisible(false);
                frame.dispose();

            }
        });

        LoginConfirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                 if (LoginUsernameTextbox.getText().isBlank()) {
                     JOptionPane.showMessageDialog(null,"Inserisci il tuo nickname");
                     return;
                 }

                 if (LoginPasswordTextBox.getPassword().length==0) {
                     JOptionPane.showMessageDialog(null,"Password non valida");
                     return;
                 }
                 if(controller.controlloEsistenzaUtenteLoggatoDB(LoginUsernameTextbox.getText(),String.valueOf(LoginPasswordTextBox.getPassword()))) {
                     controller.createUtenteLoggato(LoginUsernameTextbox.getText());
                     controller.createGalleriaUtenteLoggato("GALLERIA DI "+controller.getNicknameUtenteLoggato());
                     controller.setGalleriaVisualizzata(controller.getNomeGalleriaPersonale());
                     controller.getGallerieACuiPartecipi();
                     controller.getFotografieUtente();
                     LoginUsernameTextbox.setText(null);
                     LoginPasswordTextBox.setText(null);
                     SchermataUtente schermataUtente = new SchermataUtente(controller, frame);
                     frame.setVisible(false);
                     frame.dispose();
                 }
            }
        });
    }

    public static void main(String[] args){
        frame = new JFrame("Login");
        frame.setContentPane(new Login().SchermataLogin);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
