package GUI;

import Model.Fotografia;
import org.postgresql.jdbc.PgResultSet;

import javax.swing.*;
import java.awt.event.*;
import java.sql.SQLException;
import java.util.ArrayList;

import Controller.*;

public class SchermataRicercaFoto {
    private JLabel SchermataRicercaFotoTopFoto1;
    private JLabel SchermataRicercaFotoTopFoto2;
    private JLabel SchermataRicercaFotoTopFoto3;
    private JComboBox SchermataRicercaFotoFiltroComboBox;
    private JScrollBar SchermataRicercaFotoScrollBar;
    private JButton SchermataRicercaFotoHomeButton;
    private JButton SchermataRicercaFotoCercaButton;
    private JTextField SchermataRicercaFotoNomeFiltroTextBox;
    private JTextField SchermataRicercaFotoTipoFiltroTextBox;
    private JLabel SchermataRicercaFotoNomeFiltroLabel;
    private JLabel SchermataRicercaFotoTipoFiltroLabel;
    private JLabel SchermataRicercaFotoFoto1Label;
    private JPanel RicercaFoto;
    private JLabel SchermataRicercaFotoFoto2Label;
    private JLabel SchermataRicercaFotoFoto3Label;
    private JLabel SchermataRicercaFotoTopNomeFoto1;
    private JLabel SchermataRicercaFotoTopNomeFoto2;
    private JLabel SchermataRicercaFotoTopNomeFoto3;

    public SchermataRicercaFoto(Controller controller, JFrame schermataUtente) {

        JFrame frame = new JFrame("RicercaFoto");
        frame.setContentPane(RicercaFoto);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

//APPENA ENTRATO NELLA SCHERMATA DI RICERCA
        // recupero i 3 luoghi più immortalati dal database e li visualizzo
        try {
            SchermataRicercaFotoTopNomeFoto1.setText(controller.getNometop3LuoghiImmortalati().get(0));
            SchermataRicercaFotoTopFoto1.setIcon(controller.aggiungiFotoAllaGalleria(controller.top3LuoghiImmortalati(SchermataRicercaFotoTopNomeFoto1.getText()),300,200));
            SchermataRicercaFotoTopNomeFoto2.setText(controller.getNometop3LuoghiImmortalati().get(1));
            SchermataRicercaFotoTopFoto2.setIcon(controller.aggiungiFotoAllaGalleria(controller.top3LuoghiImmortalati(SchermataRicercaFotoTopNomeFoto2.getText()),300,200));
            SchermataRicercaFotoTopNomeFoto3.setText(controller.getNometop3LuoghiImmortalati().get(2));
            SchermataRicercaFotoTopFoto3.setIcon(controller.aggiungiFotoAllaGalleria(controller.top3LuoghiImmortalati(SchermataRicercaFotoTopNomeFoto3.getText()),300,200));
        } catch (IndexOutOfBoundsException e) {
        }
        frame.pack();
        frame.setVisible(true);


//GESTIONE DEL FILTRO
        SchermataRicercaFotoFiltroComboBox.addItemListener(new ItemListener() {

            //chiedo di inserire determinati dati in base al tipo di filtro da usare
            @Override
            public void itemStateChanged(ItemEvent e) {
                if (SchermataRicercaFotoFiltroComboBox.getSelectedIndex()==1){
                    SchermataRicercaFotoTipoFiltroLabel.setVisible(false);
                    SchermataRicercaFotoTipoFiltroTextBox.setVisible(false);
                    SchermataRicercaFotoNomeFiltroTextBox.setText("");
                    SchermataRicercaFotoNomeFiltroLabel.setText("Nome Luogo");
                    SchermataRicercaFotoNomeFiltroLabel.setVisible(true);
                    SchermataRicercaFotoNomeFiltroTextBox.setVisible(true);
                    frame.pack();
                }
                if (SchermataRicercaFotoFiltroComboBox.getSelectedIndex()==2){
                    SchermataRicercaFotoNomeFiltroTextBox.setText("");
                    SchermataRicercaFotoTipoFiltroTextBox.setText("");
                    SchermataRicercaFotoNomeFiltroLabel.setText("Nome Soggetto");
                    SchermataRicercaFotoNomeFiltroLabel.setVisible(true);
                    SchermataRicercaFotoNomeFiltroTextBox.setVisible(true);
                    SchermataRicercaFotoTipoFiltroLabel.setText("Tipo Soggetto");
                    SchermataRicercaFotoTipoFiltroLabel.setVisible(true);
                    SchermataRicercaFotoTipoFiltroTextBox.setVisible(true);
                    frame.pack();
                }

            }
        });
        SchermataRicercaFotoCercaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                //elimino i risultati del filtro precedente
                SchermataRicercaFotoFoto1Label.setIcon(null);
                SchermataRicercaFotoFoto2Label.setIcon(null);
                SchermataRicercaFotoFoto3Label.setIcon(null);

                //se il filtro scelto è per luogo di scatto, verifico che il luogo inserito esista e recupero le foto scattate nel luogo richiesto
                if (SchermataRicercaFotoFiltroComboBox.getSelectedIndex()==1)
                    if (controller.controlloEsistenzaLuogoDB(SchermataRicercaFotoNomeFiltroTextBox.getText(),null,null)==1)
                        controller.setFotoFiltrate(controller.filtraFotoPerLuogo(controller.getNicknameUtenteLoggato(), SchermataRicercaFotoNomeFiltroTextBox.getText()));
                    else
                        JOptionPane.showMessageDialog(null,"Non ci sono luoghi con quel nome");

                //se il filtro scelto è per soggetto, verifico che il soggetto inserito esista e recupero le foto che hanno quel soggetto
                if (SchermataRicercaFotoFiltroComboBox.getSelectedIndex()==2)
                    if (controller.controlloEsistenzaSoggettoDB(SchermataRicercaFotoNomeFiltroTextBox.getText(), SchermataRicercaFotoTipoFiltroTextBox.getText()))
                        controller.setFotoFiltrate(controller.filtraFotoPerSoggetto(controller.getNicknameUtenteLoggato(), SchermataRicercaFotoNomeFiltroTextBox.getText(),SchermataRicercaFotoTipoFiltroTextBox.getText()));
                    else
                        JOptionPane.showMessageDialog(null,"Non ci sono soggetti con quel nome (I tipi base sono: utente, luogo, fiera, foto di gruppo)");


                        //se le foto recuperate sono più di 3 attivo la scrollbar in modo da poterle visualizzare tutte
                        if(controller.getNumeroFotoFiltrate()>3) {
                            SchermataRicercaFotoScrollBar.setVisible(true);
                            SchermataRicercaFotoScrollBar.setValues(0, 1, 0, (controller.getNumeroFotoFiltrate() - 2));
                        }
                        try {
                                SchermataRicercaFotoFoto1Label.setIcon(controller.aggiungiFotoAllaGalleria(controller.getFotoFiltrata(0).getNomeFotografia()+controller.getFotoFiltrata(0).getIdFoto(),300,200));
                                SchermataRicercaFotoFoto2Label.setIcon(controller.aggiungiFotoAllaGalleria(controller.getFotoFiltrata(1).getNomeFotografia()+controller.getFotoFiltrata(1).getIdFoto(),300,200));
                                SchermataRicercaFotoFoto3Label.setIcon(controller.aggiungiFotoAllaGalleria(controller.getFotoFiltrata(2).getNomeFotografia()+controller.getFotoFiltrata(2).getIdFoto(),300,200));
                        } catch (IndexOutOfBoundsException ex){
                        }
                        frame.pack();
            }
        });

        SchermataRicercaFotoScrollBar.addAdjustmentListener(new AdjustmentListener() {
            @Override
            public void adjustmentValueChanged(AdjustmentEvent e) {
                SchermataRicercaFotoFoto1Label.setIcon(controller.aggiungiFotoAllaGalleria(controller.getFotoFiltrata(SchermataRicercaFotoScrollBar.getValue()).getNomeFotografia()+controller.getFotoFiltrata(SchermataRicercaFotoScrollBar.getValue()).getIdFoto(),300,200));
                SchermataRicercaFotoFoto2Label.setIcon(controller.aggiungiFotoAllaGalleria(controller.getFotoFiltrata(SchermataRicercaFotoScrollBar.getValue()+1).getNomeFotografia()+controller.getFotoFiltrata(SchermataRicercaFotoScrollBar.getValue()+1).getIdFoto(),300,200));
                SchermataRicercaFotoFoto3Label.setIcon(controller.aggiungiFotoAllaGalleria(controller.getFotoFiltrata(SchermataRicercaFotoScrollBar.getValue()+2).getNomeFotografia()+controller.getFotoFiltrata(SchermataRicercaFotoScrollBar.getValue()+2).getIdFoto(),300,200));
            }
        });

//RITORNO ALLA SCHERMATA UTENTE
        SchermataRicercaFotoHomeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                schermataUtente.setVisible(true);
                frame.setVisible(false);
                frame.dispose();
            }
        });
    }

}
