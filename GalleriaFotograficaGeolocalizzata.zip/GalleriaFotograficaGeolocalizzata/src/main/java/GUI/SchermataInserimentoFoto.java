package GUI;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import Controller.*;
import java.io.*;
import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class SchermataInserimentoFoto {
    public JFrame frame;
    private JPanel ImmagineInserita;
    private JTextField ImageNomeTextBox;
    private JTextField ImageDispositivoTextBox;
    private JTextField ImageLarghezzaTextBox;
    private JLabel ImageNomeLabel;
    private JLabel ImageDispositivo;
    private JLabel ImageSoggettolabel;
    private JTextField ImageLunghezzaTextBox;
    private JComboBox ImageSoggettoComboBox;
    private JLabel ImageElencoSoggettiLabel;
    private JTextField ImageElencoSoggettiTextBox;
    private JTextField ImageLuogoTextBox;
    private JTextField ImageLatitudineTextBox;
    private JTextField ImageLongitudineTextBox;
    private JLabel ImageLarghezzaLabel;
    private JLabel ImageLunghezzaLabel;
    private JLabel ImageLuogoLabel;
    private JLabel ImageLatitudineLabel;
    private JLabel ImageLongitudineLabel;
    private JLabel ImageDataLabel;
    private JComboBox ImageTipoComboBox;
    private JLabel ImageTipoLabel;
    private JButton ImageSalvaButton;
    private JTextField ImageNomeSoggettoTextBox;
    private JLabel ImageNomeSoggettoLabel;
    private JButton ImageAnnullaButton;
    private JLabel ImageImmagineInseritaLabel;
    private JPanel ImageImmagineInseritaPanel;
    private JLabel ImageNomeGalleriaLabel;
    private JTextField ImageDataTextBox;

    public SchermataInserimentoFoto(Controller controller,JFrame SchermataUtente, JFrame schermataLogin) {

        JFrame frame = new JFrame("InserimentoImmagine");
        frame.setContentPane(ImmagineInserita);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        ImageNomeSoggettoTextBox.setVisible(false);
        ImageNomeSoggettoLabel.setVisible(false);
        controller.createElencoTipiSoggettiFotografiaInserita();
        ImageNomeGalleriaLabel.setText(ImageNomeGalleriaLabel.getText() + controller.getGalleriaVisualizzata());
        if (!controller.getGalleriaVisualizzata().equals("GALLERIA DI "+controller.getNicknameUtenteLoggato())) {
            ImageTipoComboBox.setSelectedIndex(1);
            ImageTipoComboBox.setEnabled(false);
        }
        BufferedImage image = null;
        try {
            image = ImageIO.read(new File(controller.getPercorsoFotografiaVisualizzata()));
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "non ci sono immagini con il nome inserito");
            return;
        }
        ImageIcon icon = new ImageIcon(image.getScaledInstance(500,440, Image.SCALE_SMOOTH));
        ImageImmagineInseritaLabel.setIcon(icon);
        frame.pack();

        ImageSoggettoComboBox.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if (ImageSoggettoComboBox.getSelectedItem().equals("Utente")){
                    ImageNomeSoggettoTextBox.setVisible(true);
                    ImageNomeSoggettoLabel.setText("Nickname Utente");
                    ImageNomeSoggettoLabel.setVisible(true);
                    ImageNomeSoggettoTextBox.grabFocus();
                }

                if (ImageSoggettoComboBox.getSelectedItem().equals("Luogo")){
                    ImageNomeSoggettoTextBox.setVisible(true);
                    ImageNomeSoggettoLabel.setText("Località");
                    ImageNomeSoggettoLabel.setVisible(true);
                    ImageNomeSoggettoTextBox.grabFocus();
                }
                if (!ImageSoggettoComboBox.getSelectedItem().equals("Utente") && !ImageSoggettoComboBox.getSelectedItem().equals("Luogo")){
                    ImageNomeSoggettoTextBox.setVisible(false);
                    ImageNomeSoggettoLabel.setVisible(false);
                    ImageNomeSoggettoTextBox.setText("");
                }
                if (ImageSoggettoComboBox.getSelectedItem().equals("Fiera"))
                    if (!ImageElencoSoggettiTextBox.getText().contains("Fiera")) {
                        controller.addSoggettoFotografiaInserita("fiera");
                        if (ImageElencoSoggettiTextBox.getText().isBlank())
                            ImageElencoSoggettiTextBox.setText("Fiera");
                        else
                            ImageElencoSoggettiTextBox.setText(ImageElencoSoggettiTextBox.getText() + ", Fiera");
                    }

                if (ImageSoggettoComboBox.getSelectedItem().equals("Foto di gruppo"))
                    if (!ImageElencoSoggettiTextBox.getText().contains("Foto di gruppo")) {
                        controller.addSoggettoFotografiaInserita("foto di gruppo");
                        if (ImageElencoSoggettiTextBox.getText().isBlank())
                            ImageElencoSoggettiTextBox.setText("Foto di gruppo");
                        else
                            ImageElencoSoggettiTextBox.setText(ImageElencoSoggettiTextBox.getText() + ", Foto di gruppo");
                    }

                if (ImageSoggettoComboBox.getSelectedItem().equals("Altro"))
                    if (!ImageElencoSoggettiTextBox.getText().contains("Altro")) {
                        controller.addSoggettoFotografiaInserita("altro");
                        if (ImageElencoSoggettiTextBox.getText().isBlank())
                            ImageElencoSoggettiTextBox.setText("Altro");
                        else
                            ImageElencoSoggettiTextBox.setText(ImageElencoSoggettiTextBox.getText() + ", Altro");
                    }

                if (ImageSoggettoComboBox.getSelectedItem().equals("Selfie"))
                    if (!ImageElencoSoggettiTextBox.getText().contains(controller.getNicknameUtenteLoggato())) {
                        controller.addSoggettoFotografiaInserita("utente");
                        if (ImageElencoSoggettiTextBox.getText().isBlank())
                            ImageElencoSoggettiTextBox.setText(controller.getNicknameUtenteLoggato());
                        else
                            ImageElencoSoggettiTextBox.setText(ImageElencoSoggettiTextBox.getText() + ", " + controller.getNicknameUtenteLoggato());
                    }
            }
        });

        ImageNomeSoggettoTextBox.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                super.keyPressed(e);
                if (e.getKeyCode()==KeyEvent.VK_ENTER) {
                    if (ImageSoggettoComboBox.getSelectedItem().equals("Utente"))
                        if(!(ImageElencoSoggettiTextBox.getText().equals(ImageNomeSoggettoTextBox.getText()) || ImageElencoSoggettiTextBox.getText().contains(", "+ImageNomeSoggettoTextBox.getText()+"," ) || ImageElencoSoggettiTextBox.getText().contains(", "+ImageNomeSoggettoTextBox.getText())))
                            if (controller.controlloEsistenzaUtenteDB(ImageNomeSoggettoTextBox.getText())) {
                                controller.addSoggettoFotografiaInserita("utente");
                                if (ImageElencoSoggettiTextBox.getText().isBlank())
                                    ImageElencoSoggettiTextBox.setText(ImageNomeSoggettoTextBox.getText());
                                else
                                    ImageElencoSoggettiTextBox.setText(ImageElencoSoggettiTextBox.getText() + ", " + ImageNomeSoggettoTextBox.getText());
                            }
                    if (ImageSoggettoComboBox.getSelectedItem().equals("Luogo")) {
                        if (!(ImageElencoSoggettiTextBox.getText().equals(ImageNomeSoggettoTextBox.getText()) || ImageElencoSoggettiTextBox.getText().contains(", " + ImageNomeSoggettoTextBox.getText() + ",") || ImageElencoSoggettiTextBox.getText().contains(", " + ImageNomeSoggettoTextBox.getText())))
                            if (controller.controlloEsistenzaLuogoDB(ImageNomeSoggettoTextBox.getText(), null, null)==0)
                                controller.inserimentoLuogoDB(ImageNomeSoggettoTextBox.getText(), null, null);
                        controller.addSoggettoFotografiaInserita("luogo");
                        if (ImageElencoSoggettiTextBox.getText().isBlank())
                            ImageElencoSoggettiTextBox.setText(ImageNomeSoggettoTextBox.getText());
                        else
                            ImageElencoSoggettiTextBox.setText(ImageElencoSoggettiTextBox.getText() + ", " + ImageNomeSoggettoTextBox.getText());
                    }

                    ImageNomeSoggettoTextBox.setText(null);
                    ImageNomeSoggettoTextBox.setVisible(false);
                    ImageNomeSoggettoLabel.setVisible(false);
                    ImageSoggettoComboBox.setSelectedIndex(0);
                }
            }
        });

        ImageNomeTextBox.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                super.keyPressed(e);
                if (e.getKeyCode()==KeyEvent.VK_ENTER) {
                    BufferedImage image = null;
                    try {
                        image = ImageIO.read(new File(Login.class.getProtectionDomain().getCodeSource().getLocation().getPath().substring(0,Login.class.getProtectionDomain().getCodeSource().getLocation().getPath().indexOf("Geolocalizzata")+14)+"/src/immagini/"+ImageNomeTextBox.getText()+".jpg"));
                    } catch (IOException ex) {
                        JOptionPane.showMessageDialog(null, "non ci sono immagini con il nome inserito");
                        return;
                    }
                    ImageIcon icon = new ImageIcon(image.getScaledInstance(500,400, Image.SCALE_SMOOTH));
                    ImageImmagineInseritaLabel.setIcon(icon);
                    frame.pack();
                }
            }
        });

        ImageSalvaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (ImageNomeTextBox.getText().isBlank() || !ImageNomeTextBox.getText().matches("^[a-zA-Z0-9_# ]*$")){
                    JOptionPane.showMessageDialog(null, "Inserisci un nome valido (Max 30 caratteri alfanumerici, underscore o hashtag)");
                    return;
                }

                if (ImageDispositivoTextBox.getText().isBlank() || !ImageDispositivoTextBox.getText().matches("^[a-zA-Z0-9_# ]*$")){
                    JOptionPane.showMessageDialog(null, "Inserisci un dispositivo valido (Max 30 caratteri alfanumerici, underscore o hashtag)");
                    return;
                }

                if (ImageElencoSoggettiTextBox.getText().isBlank()) {
                    JOptionPane.showMessageDialog(null, "Inserisci almeno un soggetto della foto");
                    return;
                }

                if (ImageLuogoTextBox.getText().isBlank() || !ImageLuogoTextBox.getText().matches("^[a-zA-Z0-9_# ]*$")){
                    JOptionPane.showMessageDialog(null, "Inserisci il luogo in cui è stata scattata la foto (Max 30 caratteri alfanumerici, underscore o hashtag)");
                    return;
                }

                controller.createFotografiaInserita(ImageNomeTextBox.getText(), ImageDispositivoTextBox.getText(), true, controller.getUtenteLoggato());

                if (ImageTipoComboBox.getSelectedItem() == "Privata")
                    controller.setVisibilitaFotografiaInserita(false);
                else
                    controller.setVisibilitaFotografiaInserita(true);

                if(!ImageDataTextBox.getText().isBlank())
                    if(ImageDataTextBox.getText().matches("^\\d{2}-\\d{2}-\\d{4}$")){
                        try{
                            SimpleDateFormat data = new SimpleDateFormat("dd-MM-yyyy");
                            data.setLenient(false);

                            controller.setDataFotografiaInserita(data.parse(ImageDataTextBox.getText()));
                        } catch(ParseException ex){
                            JOptionPane.showMessageDialog(null,"Data Inserita non valida");
                            return;
                        }
                    } else {
                        JOptionPane.showMessageDialog(null,"Data Inserita non valida");
                        return;
                    }

                if (!ImageLarghezzaTextBox.getText().isBlank() || !ImageLunghezzaTextBox.getText().isBlank())
                    try {
                        if((Integer.parseInt(ImageLarghezzaTextBox.getText())>9999 || Integer.parseInt(ImageLarghezzaTextBox.getText())<1) || (Integer.parseInt(ImageLunghezzaTextBox.getText())>9999 || Integer.parseInt(ImageLunghezzaTextBox.getText())<1)){
                            JOptionPane.showMessageDialog(null, "Dimensioni massime 9999 x 9999");
                            return;
                        }
                        controller.setDimensioniFotografiaInserita(Integer.parseInt(ImageLarghezzaTextBox.getText()),Integer.parseInt(ImageLunghezzaTextBox.getText()));
                    } catch (NumberFormatException exception) {
                        JOptionPane.showMessageDialog(null, "inserisci dimensioni valide");
                        return;
                    }
                else
                    controller.setDimensioniFotografiaInserita(null,null);


                if (!ImageLatitudineTextBox.getText().isBlank() && !ImageLongitudineTextBox.getText().isBlank()) {
                    try {
                        if (Double.parseDouble(ImageLatitudineTextBox.getText()) > 999 || Double.parseDouble(ImageLongitudineTextBox.getText()) > 999) {
                            JOptionPane.showMessageDialog(null, "inserisci coordinate valide");
                            return;
                        } else {
                            controller.setLuogoFotografiaInserita(ImageLuogoTextBox.getText(),Double.parseDouble(ImageLatitudineTextBox.getText()), Double.parseDouble(ImageLongitudineTextBox.getText()));
                            if (controller.controlloEsistenzaLuogoDB(ImageLuogoTextBox.getText(), Double.parseDouble(ImageLatitudineTextBox.getText()), Double.parseDouble(ImageLongitudineTextBox.getText())) == -1)
                                return;
                            if (controller.controlloEsistenzaLuogoDB(ImageLuogoTextBox.getText(), Double.parseDouble(ImageLatitudineTextBox.getText()), Double.parseDouble(ImageLongitudineTextBox.getText())) == 0)
                                controller.inserimentoLuogoDB(ImageLuogoTextBox.getText(),Double.parseDouble(ImageLatitudineTextBox.getText()), Double.parseDouble(ImageLongitudineTextBox.getText()));
                        }
                    } catch (NumberFormatException exception) {
                        JOptionPane.showMessageDialog(null, "inserisci coordinate valide");
                        return;
                    }
                } else {
                    controller.setLuogoFotografiaInserita(ImageLuogoTextBox.getText(), 0.0, 0.0);
                    if (controller.controlloEsistenzaLuogoDB(ImageLuogoTextBox.getText(), null,null) == -1)
                        return;
                    else if (controller.controlloEsistenzaLuogoDB(ImageLuogoTextBox.getText(), null,null) == 0)
                            controller.inserimentoLuogoDB(ImageLuogoTextBox.getText(),null,null);
                }

                controller.setSoggettiFotografiaInserita(ImageElencoSoggettiTextBox.getText());

                controller.inserimentoFotografiaDB();

                controller.inserimentoSoggettiDB(ImageElencoSoggettiTextBox.getText());

                if (controller.getGalleriaVisualizzata().equals("GALLERIA DI "+controller.getNicknameUtenteLoggato())) {
                    controller.inserimentoFotografiaInGalleriaPersonaleDB();
                    controller.insertFotoInGalleriaPersonale(controller.setFotografiaInserita());
                }
                else
                    controller.inserimentoFotografiaInGalleriaCondivisaDB(controller.getFotografiaInserita().getIdFoto(), Integer.valueOf(controller.getGalleriaVisualizzata().substring(controller.getGalleriaVisualizzata().lastIndexOf("#")+1)));

                try (InputStream is = new FileInputStream(controller.getPercorsoFotografiaVisualizzata());
                     OutputStream os = new FileOutputStream(Login.class.getProtectionDomain().getCodeSource().getLocation().getPath().substring(0,Login.class.getProtectionDomain().getCodeSource().getLocation().getPath().indexOf("Geolocalizzata")+14)+"/src/immagini/"+controller.getFotografiaInserita().getNomeFotografia()+controller.getFotografiaInserita().getIdFoto()+".jpg"))
                {
                    byte[] buffer = new byte[1024];
                    int len;
                    while ((len = is.read(buffer)) != -1) {
                        os.write(buffer, 0, len);
                    }
                } catch (IOException ex){

                }
                SchermataUtente schermataUtente = new SchermataUtente(controller,schermataLogin, frame);
                frame.setVisible(false);
                frame.dispose();
            }
        });

        ImageAnnullaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SchermataUtente schermataUtente = new SchermataUtente(controller, frame, schermataLogin);
                frame.setVisible(false);
                frame.dispose();
            }
        });
    }
}
