package GUI;

import Controller.Controller;
import Model.Fotografia;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SchermataVisualizzazioneFotografia {
    private JTextField SchermataVisualizzazioneFotografiaNomeTextBox;
    private JTextField SchermataVisualizzazioneFotografiaDispositivoTextBox;
    private JTextField SchermataVisualizzazioneFotografiaElencoSoggettiTextBox;
    private JTextField SchermataVisualizzazioneFotografiaTipoTextBox;
    private JTextField SchermataVisualizzazioneFotografiaDimensioniTextBox;
    private JTextField SchermataVisualizzazioneFotografiaDataScattoTextBox;
    private JTextField SchermataVisualizzazioneFotografiaLuogoScattoTextBox;
    private JLabel SchermataVisualizzazioneFotografiaFotoLabel;
    private JPanel ImmagineVisualizzata;
    private JButton SchermataVisualizzazioneFotografiaHomeButton;
    private JButton SchermataVisualizzazioneFotografiaEliminaFotoButton;
    private JTextField SchermataVisualizzazioneFotografiaFotografoTextBox;
    private JButton SchermataVisualizzazioneFotografiaCondividiFotoButton;
    private JButton SchermataVisualizzazioneFotografiaPrivatizzaFotoButton;


    public SchermataVisualizzazioneFotografia(Controller controller, JFrame schermataUtente, JFrame schermataLogin, Fotografia fotografia){

        JFrame frame = new JFrame("ImmagineVisualizzata");
        frame.setContentPane(ImmagineVisualizzata);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        SchermataVisualizzazioneFotografiaNomeTextBox.setText(fotografia.getNomeFotografia());
        SchermataVisualizzazioneFotografiaFotografoTextBox.setText(fotografia.getFotografo());
        SchermataVisualizzazioneFotografiaDispositivoTextBox.setText(fotografia.getDispositivoFotografia());
        SchermataVisualizzazioneFotografiaDimensioniTextBox.setText(fotografia.getDimensioniFotografia());
        SchermataVisualizzazioneFotografiaDataScattoTextBox.setText(String.valueOf(fotografia.getDataScatto()));
        if (SchermataVisualizzazioneFotografiaDimensioniTextBox.getText().equals("nullxnull"))
            SchermataVisualizzazioneFotografiaDimensioniTextBox.setText("none");
        SchermataVisualizzazioneFotografiaTipoTextBox.setText(fotografia.getVisibilitaFotografia());
        SchermataVisualizzazioneFotografiaLuogoScattoTextBox.setText(controller.getCoordinateLuogoFotografia(fotografia));
        if (controller.getGalleriaVisualizzata().equals(controller.getNomeGalleriaPersonale()))
            SchermataVisualizzazioneFotografiaFotoLabel.setIcon(controller.aggiungiFotoAllaGalleria(controller.getFotografia(controller.getPosizioneFoto(fotografia)).getNomeFotografia()+controller.getFotografia(controller.getPosizioneFoto(fotografia)).getIdFoto(), 500, 400));
        else
            SchermataVisualizzazioneFotografiaFotoLabel.setIcon(controller.aggiungiFotoAllaGalleriaCondivisa(controller.getPosizioneFotoGC(fotografia),500, 400));
        SchermataVisualizzazioneFotografiaElencoSoggettiTextBox.setText(fotografia.getElencoSoggettiFotografia());
        if(controller.getFotografiaVisualizzata().getFotografo().equals(controller.getNicknameUtenteLoggato())){
            SchermataVisualizzazioneFotografiaPrivatizzaFotoButton.setEnabled(true);
            SchermataVisualizzazioneFotografiaCondividiFotoButton.setEnabled(true);
        }
        else {
            SchermataVisualizzazioneFotografiaPrivatizzaFotoButton.setEnabled(false);
            SchermataVisualizzazioneFotografiaCondividiFotoButton.setEnabled(false);
        }
        frame.pack();

        SchermataVisualizzazioneFotografiaHomeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                schermataUtente.setVisible(true);
                frame.setVisible(false);
                frame.dispose();

            }
        });
        SchermataVisualizzazioneFotografiaEliminaFotoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (controller.getGalleriaVisualizzata().equals(controller.getNomeGalleriaPersonale())) {
                    controller.removeFotografia(fotografia);
                    controller.rimuoviFotografiaDaGalleriaPersonaleDB(fotografia.getIdFoto());
                } else
                    controller.rimuoviFotografiaDaGalleriaCondivisaDB(fotografia.getIdFoto());
                SchermataUtente schermataUtente = new SchermataUtente(controller, schermataLogin, frame);
                frame.setVisible(false);
                frame.dispose();
            }
        });
        SchermataVisualizzazioneFotografiaCondividiFotoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controller.setGalleriaVisualizzata(JOptionPane.showInputDialog("Inserisci il nome della galleria in cui vuoi condividere la foto"));
                if (controller.controlloEsistenzaGalleriaCondivisaDB(controller.getGalleriaVisualizzata(),controller.getNicknameUtenteLoggato())) {
                    controller.rendiFotoPubblica(controller.getFotografiaVisualizzata());
                    controller.inserimentoFotografiaInGalleriaCondivisaDB(controller.getFotografiaVisualizzata().getIdFoto(), Integer.valueOf(controller.getGalleriaVisualizzata().substring(controller.getGalleriaVisualizzata().lastIndexOf("#") + 1)));
                }
                schermataUtente.setVisible(true);
                frame.setVisible(false);
                frame.dispose();
            }
        });
        SchermataVisualizzazioneFotografiaPrivatizzaFotoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controller.getFotografiaVisualizzata().setVisibilita(false);
                controller.privatizzaFoto(controller.getFotografiaVisualizzata());
                SchermataUtente schermataUtente = new SchermataUtente(controller, schermataLogin, frame);
                frame.setVisible(false);
                frame.dispose();
            }
        });
    }
}



