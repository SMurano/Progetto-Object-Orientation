package GUI;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.filechooser.FileSystemView;
import java.awt.event.*;

import Controller.Controller;

public class SchermataUtente {
    public JFrame frame;
    private JLabel SchermataUtenteLabel;
    private JLabel SchermataUtenteGalleriaPersonaleLabel;
    private JPanel SchermataHome;
    private JLabel SchermataUtentegalleriaCondivisaLabel;
    private JScrollBar SchermataUtenteScrollbar1;
    private JScrollBar SchermataUtenteScrollbar2;
    private JButton SchermataUtenteGalleriaPersonaleInserisciFotoButton;
    private JButton SchermataUtenteCreazioneGalleriaCondivisaButton;
    private JButton SchermataHomeLogOutButton;
    private JLabel SchermataUtenteFotografia1Label;
    private JLabel SchermataUtenteFotografia2Label;
    private JLabel SchermataUtenteFotografia3Label;
    private JLabel SchermataUtenteGalleriaCondivisa1Label;
    private JLabel SchermataUtenteGalleriaCondivisa2Label;
    private JPanel SchermataUtenteGalleriaCondivisa1Panel;
    private JPanel SchermataUtenteGalleriaCondivisa2Panel;
    private JLabel SchermataUtenteGalleriaCondivisaNome1Label;
    private JPanel SchermataUtenteGalleriaCondivisa3Panel;
    private JLabel SchermataUtenteGalleriaCondivisaNome2Label;
    private JLabel SchermataUtenteGalleriaCondivisaNome3Label;
    private JLabel SchermataUtenteGalleriaCondivisa3Label;
    private JButton SchermataUtenteGalleriaPersonaleRicercaFotoButton;


    public SchermataUtente(Controller controller,JFrame schermataLogin, JFrame schermataPrecedente) {

        JFrame frame = new JFrame("Home");
        frame.setContentPane(SchermataHome);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);

        SchermataUtenteLabel.setText(SchermataUtenteLabel.getText() + ' ' + controller.getNicknameUtenteLoggato());

        try {
            if (controller.getNumeroFoto() > 3) {
                SchermataUtenteScrollbar1.setVisible(true);
                SchermataUtenteScrollbar1.setValues(0, 1, 0, (controller.getNumeroFoto() - 2));
            }
            SchermataUtenteFotografia1Label.setIcon(controller.aggiungiFotoAllaGalleria(controller.getFotografia(0).getNomeFotografia()+controller.getFotografia(0).getIdFoto(), 300, 200));
            SchermataUtenteFotografia2Label.setIcon(controller.aggiungiFotoAllaGalleria(controller.getFotografia(1).getNomeFotografia()+controller.getFotografia(1).getIdFoto(), 300, 200));
            SchermataUtenteFotografia3Label.setIcon(controller.aggiungiFotoAllaGalleria(controller.getFotografia(2).getNomeFotografia()+controller.getFotografia(2).getIdFoto(), 300, 200));
        } catch (IndexOutOfBoundsException e){
        }

        if (controller.getNumeroGallerieACuiPartecipi()>3){
            SchermataUtenteScrollbar2.setVisible(true);
            SchermataUtenteScrollbar2.setValues(0,1,0,(controller.getNumeroGallerieACuiPartecipi() -2));
        }

        SchermataUtenteGalleriaCondivisaNome1Label.setText(controller.getGalleriaCondivisa(0));
        SchermataUtenteGalleriaCondivisaNome2Label.setText(controller.getGalleriaCondivisa(1));
        SchermataUtenteGalleriaCondivisaNome3Label.setText(controller.getGalleriaCondivisa(2));

        try {
            SchermataUtenteGalleriaCondivisa1Label.setIcon(controller.getCopertinaGalleriaCondivisa(Integer.valueOf(SchermataUtenteGalleriaCondivisaNome1Label.getText().substring(SchermataUtenteGalleriaCondivisaNome1Label.getText().lastIndexOf('#') + 1))));
            SchermataUtenteGalleriaCondivisa2Label.setIcon(controller.getCopertinaGalleriaCondivisa(Integer.valueOf(SchermataUtenteGalleriaCondivisaNome2Label.getText().substring(SchermataUtenteGalleriaCondivisaNome2Label.getText().lastIndexOf('#') + 1))));
            SchermataUtenteGalleriaCondivisa3Label.setIcon(controller.getCopertinaGalleriaCondivisa(Integer.valueOf(SchermataUtenteGalleriaCondivisaNome3Label.getText().substring(SchermataUtenteGalleriaCondivisaNome3Label.getText().lastIndexOf('#') + 1))));
        } catch (NumberFormatException e){
        }
        frame.pack();

        SchermataUtenteGalleriaPersonaleInserisciFotoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controller.setGalleriaVisualizzata(controller.getNomeGalleriaPersonale());
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setAcceptAllFileFilterUsed(false);
                fileChooser.setCurrentDirectory(FileSystemView.getFileSystemView().getHomeDirectory().getAbsoluteFile());
                fileChooser.addChoosableFileFilter(new FileNameExtensionFilter("Immagini","jpg","png"));
                if (fileChooser.showOpenDialog(null)==JFileChooser.APPROVE_OPTION) {
                    controller.setPercorsoFotografiaVisualizzata(fileChooser.getSelectedFile().getAbsolutePath());
                    SchermataInserimentoFoto schermataInserimentoFoto = new SchermataInserimentoFoto(controller, frame, schermataLogin);
                    frame.setVisible(false);
                    frame.dispose();
                    frame.pack();
                }
            }
        });

        SchermataUtenteFotografia1Label.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                controller.setFotografiaVisualizzata(controller.getFotografia(SchermataUtenteScrollbar1.getValue()));
                controller.setGalleriaVisualizzata(controller.getNomeGalleriaPersonale());
                SchermataVisualizzazioneFotografia schermataVisualizzazioneFotografia = new SchermataVisualizzazioneFotografia(controller, frame, schermataLogin, controller.getFotografiaVisualizzata());
                frame.setVisible(false);
                frame.dispose();
            }
        });

        SchermataUtenteFotografia2Label.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                controller.setFotografiaVisualizzata(controller.getFotografia(SchermataUtenteScrollbar1.getValue()+1));
                controller.setGalleriaVisualizzata(controller.getNomeGalleriaPersonale());
                SchermataVisualizzazioneFotografia schermataVisualizzazioneFotografia = new SchermataVisualizzazioneFotografia(controller, frame, schermataLogin, controller.getFotografiaVisualizzata());
                frame.setVisible(false);
                frame.dispose();
            }
        });

        SchermataUtenteFotografia3Label.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                controller.setFotografiaVisualizzata(controller.getFotografia(SchermataUtenteScrollbar1.getValue()+2));
                controller.setGalleriaVisualizzata(controller.getNomeGalleriaPersonale());
                SchermataVisualizzazioneFotografia schermataVisualizzazioneFotografia = new SchermataVisualizzazioneFotografia(controller, frame, schermataLogin, controller.getFotografiaVisualizzata());
                frame.setVisible(false);
                frame.dispose();
            }
        });

        SchermataUtenteScrollbar1.addAdjustmentListener(new AdjustmentListener() {
            @Override
            public void adjustmentValueChanged(AdjustmentEvent e) {
                SchermataUtenteFotografia1Label.setIcon(controller.aggiungiFotoAllaGalleria(controller.getFotografia(SchermataUtenteScrollbar1.getValue()).getNomeFotografia()+controller.getFotografia(SchermataUtenteScrollbar1.getValue()).getIdFoto(), 300, 200));
                SchermataUtenteFotografia2Label.setIcon(controller.aggiungiFotoAllaGalleria(controller.getFotografia(SchermataUtenteScrollbar1.getValue()+1).getNomeFotografia()+controller.getFotografia(SchermataUtenteScrollbar1.getValue()+1).getIdFoto(), 300, 200));
                SchermataUtenteFotografia3Label.setIcon(controller.aggiungiFotoAllaGalleria(controller.getFotografia(SchermataUtenteScrollbar1.getValue()+2).getNomeFotografia()+controller.getFotografia(SchermataUtenteScrollbar1.getValue()+2).getIdFoto(), 300, 200));
                frame.pack();
            }
        });

        SchermataUtenteGalleriaCondivisaNome1Label.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                controller.setGalleriaVisualizzata(SchermataUtenteGalleriaCondivisaNome1Label.getText());
                controller.recuperoNomiFotografieGalleriaCondivisaDB();
                SchermataVisualizzaGalleria schermataVisualizzaGalleria = new SchermataVisualizzaGalleria(controller, frame, schermataLogin);
                frame.setVisible(false);
                frame.dispose();
            }
        });
        SchermataUtenteGalleriaCondivisaNome2Label.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                controller.setGalleriaVisualizzata(SchermataUtenteGalleriaCondivisaNome2Label.getText());
                controller.recuperoNomiFotografieGalleriaCondivisaDB();
                SchermataVisualizzaGalleria schermataVisualizzaGalleria = new SchermataVisualizzaGalleria(controller, frame, schermataLogin);
                frame.setVisible(false);
                frame.dispose();
            }
        });
        SchermataUtenteGalleriaCondivisaNome3Label.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                controller.setGalleriaVisualizzata(SchermataUtenteGalleriaCondivisaNome3Label.getText());
                controller.recuperoNomiFotografieGalleriaCondivisaDB();
                SchermataVisualizzaGalleria schermataVisualizzaGalleria = new SchermataVisualizzaGalleria(controller, frame, schermataLogin);
                frame.setVisible(false);
                frame.dispose();
            }
        });

        SchermataUtenteScrollbar2.addAdjustmentListener(new AdjustmentListener() {
            @Override
            public void adjustmentValueChanged(AdjustmentEvent e) {
                SchermataUtenteGalleriaCondivisaNome1Label.setText(controller.getGalleriaCondivisa(SchermataUtenteScrollbar2.getValue()));
                SchermataUtenteGalleriaCondivisaNome2Label.setText(controller.getGalleriaCondivisa((SchermataUtenteScrollbar2.getValue() + 1)));
                SchermataUtenteGalleriaCondivisaNome3Label.setText(controller.getGalleriaCondivisa((SchermataUtenteScrollbar2.getValue() + 2)));
                try {
                    SchermataUtenteGalleriaCondivisa1Label.setIcon(controller.getCopertinaGalleriaCondivisa(Integer.valueOf(SchermataUtenteGalleriaCondivisaNome1Label.getText().substring(SchermataUtenteGalleriaCondivisaNome1Label.getText().lastIndexOf('#') + 1))));
                    SchermataUtenteGalleriaCondivisa2Label.setIcon(controller.getCopertinaGalleriaCondivisa(Integer.valueOf(SchermataUtenteGalleriaCondivisaNome2Label.getText().substring(SchermataUtenteGalleriaCondivisaNome2Label.getText().lastIndexOf('#') + 1))));
                    SchermataUtenteGalleriaCondivisa3Label.setIcon(controller.getCopertinaGalleriaCondivisa(Integer.valueOf(SchermataUtenteGalleriaCondivisaNome3Label.getText().substring(SchermataUtenteGalleriaCondivisaNome3Label.getText().lastIndexOf('#') + 1))));
                } catch (NumberFormatException ex) {
                }
            }
        });

        SchermataUtenteCreazioneGalleriaCondivisaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SchermataCreazioneGalleriaCondivisa schermataCreazioneGalleriaCondivisa = new SchermataCreazioneGalleriaCondivisa(controller, frame);
                frame.setVisible(false);
                frame.dispose();
            }
        });

        SchermataHomeLogOutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                schermataLogin.setVisible(true);
                frame.setVisible(false);
                frame.dispose();
            }
        });

        SchermataUtenteGalleriaPersonaleRicercaFotoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SchermataRicercaFoto schermataRicercaFoto = new SchermataRicercaFoto(controller, frame);
                frame.setVisible(false);
                frame.dispose();
            }
        });
    }
}
