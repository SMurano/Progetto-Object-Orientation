package Controller;
import GUI.Login;
import ImplementazionePostgresDAO.*;
import Model.*;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Controller {
    private Utente utenteLoggato;
    private ImplementazioneUtenteDAO utenteDAO= new ImplementazioneUtenteDAO();
    private ImplementazioneFotografiaDAO fotografiaDAO = new ImplementazioneFotografiaDAO();
    private ImplementazioneLuogoDAO luogoDAO = new ImplementazioneLuogoDAO();
    private ImplementazioneGalleriaCondivisaDAO galleriaCondivisaDAO = new ImplementazioneGalleriaCondivisaDAO();
    private ImplementazioneGalleriaPersonaleDAO galleriaPersonaleDAO = new ImplementazioneGalleriaPersonaleDAO();
    private ImplementazioneSoggettoDAO soggettoDAO = new ImplementazioneSoggettoDAO();
    private Fotografia fotografiaInserita;
    private Fotografia fotografiaVisualizzata;
    private String percorsoFotografiaVisualizzata;
    private GalleriaPersonale galleriaUtente;
    private Luogo luogoFotografiaInserita;
    private ArrayList<String> tipiSoggettiFotografiaInserita;
    private ArrayList<String> gallerieACuiPartecipi;
    private ArrayList<String> fotoGalleriaVisualizzata;
    private GalleriaCondivisa galleriaCondivisaVisualizzata;
    private String galleriaVisualizzata;
    private ArrayList<Fotografia> fotoFiltrate;


//METODI PER IL RECUPERO E LA GESTIONE DEI DATI DELL'UTENTE LOGGATO
    public void createUtenteLoggato(String nick){
        utenteLoggato = new Utente(nick);
    }
    public Utente getUtenteLoggato(){return utenteLoggato;}
    public String getNicknameUtenteLoggato(){return utenteLoggato.getNicknameUtente();}
    public void setPasswordUtenteLoggato(String p){utenteLoggato.setPasswordUtente(p);}
    public void setNameUtenteLoggato(String n){utenteLoggato.setNomeUtente(n);}
    public void setLNameUtenteLoggato(String n){utenteLoggato.setCognomeUtente(n);}
    public void createGalleriaUtenteLoggato(String nome){
        galleriaUtente = new GalleriaPersonale(nome, utenteLoggato);
        galleriaUtente.setIdGalleria(galleriaPersonaleDAO.associaCodiceGalleria(galleriaUtente.getNomeGalleria()));
    }
    public String getNomeGalleriaPersonale(){
        return galleriaUtente.getNomeGalleria();
    }
    public void getGallerieACuiPartecipi(){
        gallerieACuiPartecipi = utenteDAO.recuperoGallerieACuiPartecipi(utenteLoggato.getNicknameUtente());
    }
    public void getFotografieUtente(){
        Boolean visibilita;
        Integer i=0;
        ResultSet elencoFoto;
        ResultSet soggettiFoto;
        //recupera le fotografie private dell'utente loggato
        elencoFoto = galleriaPersonaleDAO.recuperoFotografie(utenteLoggato.getNicknameUtente());
        try {
            while (elencoFoto.next()) {
                if (elencoFoto.getString(8).equals("pubblico"))
                    visibilita=true;
                else
                    visibilita=false;
                Fotografia fotografia = new Fotografia(elencoFoto.getString(6),elencoFoto.getString(3),visibilita,utenteLoggato);
                fotografia.setIdfoto(elencoFoto.getInt(1));
                fotografia.setDataScatto(elencoFoto.getDate(9));
                fotografia.setDimensioni(elencoFoto.getInt(4),elencoFoto.getInt(5));
                Luogo luogo = new Luogo(elencoFoto.getString(2),fotografia);
                if (elencoFoto.getString(10)!=null && elencoFoto.getString(11)!=null)
                    luogo.setCoordinate(elencoFoto.getDouble(10), elencoFoto.getDouble(11));
                fotografia.setLuogoScattoFotografia(luogo);
                galleriaUtente.addFotoInGalleria(fotografia);
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        //per ogni foto recupera i soggetti e glieli associa
        while (i<galleriaUtente.getNumeroFoto()) {
            soggettiFoto = fotografiaDAO.recuperoSoggettiFoto(utenteLoggato.getNicknameUtente(),galleriaUtente.getFotoDaGalleria(i).getIdFoto());
            try {
                while (soggettiFoto.next()) {
                    if (soggettiFoto.getString(2).equals("utente")) {
                        Utente utente1 = new Utente(soggettiFoto.getString(3));
                        Soggetto soggetto = new Soggetto(utente1, galleriaUtente.getFotoDaGalleria(i));
                        soggetto.setCodiceSoggetto(soggettiFoto.getInt(1));
                    } else if (soggettiFoto.getString(2).equals("luogo")) {
                        Luogo luogo = new Luogo(soggettiFoto.getString(4));
                        Soggetto soggetto = new Soggetto(luogo, galleriaUtente.getFotoDaGalleria(i));
                        soggetto.setCodiceSoggetto(soggettiFoto.getInt(1));
                    } else {
                        Soggetto soggetto = new Soggetto(soggettiFoto.getString(2), galleriaUtente.getFotoDaGalleria(i));
                        soggetto.setCodiceSoggetto(soggettiFoto.getInt(1));
                    }
                }

            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            i++;
        }
    }
    public void insertFotoInGalleriaPersonale(Fotografia f){
        galleriaUtente.addFotoInGalleria(f);
    }
    public Fotografia getFotografia(Integer i){
        return galleriaUtente.getFotoDaGalleria(i);
    }
    public void removeFotografia(Fotografia f){galleriaUtente.deleteFotografia(f);}
    public String getCoordinateLuogoFotografia(Fotografia f){
        return f.getLuogoScattoFotografia().getCoordinateFotografia(f);
    }
    public Integer getNumeroFoto(){
        return galleriaUtente.getNumeroFoto();
    }
    public Integer getPosizioneFoto(Fotografia f){
        return galleriaUtente.getPosizioneFoto(f);
    }
    public Integer getPosizioneFotoGC(Fotografia f){
        return galleriaCondivisaVisualizzata.getPosizioneFoto(f);
    }
    public Integer getNumeroGallerieACuiPartecipi(){
        return gallerieACuiPartecipi.size();
    }
    public void rendiFotoPubblica(Fotografia f){
        f.setVisibilita(true);
        fotografiaDAO.rendiFotoPubblica(f.getIdFoto());
    }
    public void privatizzaFoto(Fotografia f){
        fotografiaDAO.privatizzaFoto(f.getIdFoto());
    }
    public void addGalleriaCondivisa(){
        gallerieACuiPartecipi.add(galleriaCondivisaDAO.recuperoGalleriaInserita(getNicknameUtenteLoggato()));
    }
    public String getGalleriaCondivisa(Integer i){
        try {
            gallerieACuiPartecipi.get(i);
        } catch (IndexOutOfBoundsException e) {
            return "";
        }
        return gallerieACuiPartecipi.get(i);
    }


//METODI PER LA VISUALIZZAZIONE DELLE INFORMAZIONI DI UNA SPECIFICA FOTOGRAFIA
    public void setFotografiaVisualizzata(Fotografia f){
        fotografiaVisualizzata= f;
    }
    public Fotografia getFotografiaVisualizzata(){
        return fotografiaVisualizzata;
    }
    public Fotografia getFotoGalleriaCondivisaVisualizzata(Integer i){
        return galleriaCondivisaVisualizzata.getFotoDaGalleria(i);
    }
    public void setPercorsoFotografiaVisualizzata(String path){
        percorsoFotografiaVisualizzata=path;
    }
    public String getPercorsoFotografiaVisualizzata(){
        return percorsoFotografiaVisualizzata;
    }
    public Integer getNumeroFotoGalleriaVisualizzata(){return fotoGalleriaVisualizzata.size();}



//METODI PER LA VISUALIZZAZIONE DELLE INFORMAZIONI DI UNA SPECIFICA GALLERIA CONDIVISA
    public void setGalleriaVisualizzata(String nomeGalleria){
        galleriaVisualizzata=nomeGalleria;
    }
    public String getGalleriaVisualizzata(){
        return galleriaVisualizzata;
    }

    //crea una stringa costituita da tutti i nicknames dei partecipanti di una certa galleria condivisa
    public String getNicknamesUtentiPartecipantiGalleriaVisualizzata(){
        String nicknames = "";
        int i=0;
        ArrayList <String> nicknamesUtenti=galleriaCondivisaVisualizzata.getNicknamesUtentiPartecipanti();
        while(i<nicknamesUtenti.size()){
            nicknames=nicknames.concat(" "+nicknamesUtenti.get(i));
            i++;
        }
        return nicknames;
    }


//METODI PER LA GESTIONE DELL'INSERIMENTO DI UNA NUOVA FOTOGRAFIA
    public void createFotografiaInserita(String n, String d,Boolean v, Utente utente){
        fotografiaInserita = new Fotografia(n, d, v, utente);
    }
    public Fotografia getFotografiaInserita(){return fotografiaInserita;}
    public void setDataFotografiaInserita(Date d){
        fotografiaInserita.setDataScatto(d);
    }
    public void setDimensioniFotografiaInserita(Integer l, Integer a){
        fotografiaInserita.setDimensioni(l,a);
    }
    public Fotografia setFotografiaInserita(){
        return fotografiaInserita;
    }
    public void setVisibilitaFotografiaInserita(Boolean v){
        fotografiaInserita.setVisibilita(v);
    }
    public void setLuogoFotografiaInserita(String nome,Double lat, Double lon){
        luogoFotografiaInserita = new Luogo(nome,lat,lon,fotografiaInserita);
    }
    public void updateLuogoFotografiaInserita(Double lat, Double lon){
        if (luogoFotografiaInserita!=null)
            luogoFotografiaInserita.setCoordinate(lat,lon);
    }
    public void setNomeLuogoScattoFotografiaInserita(String s){
        luogoFotografiaInserita.setNomeLuogo(s);}
    public void addSoggettoFotografiaInserita(String tipoSoggetto){
        try {
            tipiSoggettiFotografiaInserita.add(tipoSoggetto);
        } catch (NullPointerException e){
            tipiSoggettiFotografiaInserita= new ArrayList<>();
            tipiSoggettiFotografiaInserita.add(tipoSoggetto);
        }
    }
    public void createElencoTipiSoggettiFotografiaInserita(){
        tipiSoggettiFotografiaInserita= new ArrayList<>();
    }
    public void setSoggettiFotografiaInserita(String elencoSoggetti){
        ArrayList<String> soggetti = new ArrayList<>(List.of(elencoSoggetti.split(",")));
        Integer i=0;
        while(i<soggetti.size()){
            if (tipiSoggettiFotografiaInserita.get(i).equals("Utente")){
                Utente utente = new Utente(soggetti.get(i));
                Soggetto soggetto = new Soggetto(utente,fotografiaInserita);
            } else if (tipiSoggettiFotografiaInserita.get(i).equals("Luogo")){

            } else {
                Soggetto soggetto = new Soggetto(soggetti.get(i),fotografiaInserita);
            }
            i++;
        }
    }


//METODI PER LA VISUALIZZAZIONE DEI FILE IMMAGINE
    //permette di visualizzare la versione scalata di una certa immagine
    public ImageIcon  aggiungiFotoAllaGalleria(String nomeFoto, Integer width, Integer height){
        try {
            if (!nomeFoto.isBlank()) {
                BufferedImage image = null;
                try {
                    image = ImageIO.read(new File(Login.class.getProtectionDomain().getCodeSource().getLocation().getPath().substring(0,Login.class.getProtectionDomain().getCodeSource().getLocation().getPath().indexOf("Geolocalizzata")+14)+"/src/immagini/" + nomeFoto + ".jpg"));
                } catch (IOException ex) {
                }
                ImageIcon icon = new ImageIcon(image.getScaledInstance(width, height, Image.SCALE_SMOOTH));
                return icon;
            }
        } catch (NullPointerException exception){
            BufferedImage image = null;
            try {
                image = ImageIO.read(new File(Login.class.getProtectionDomain().getCodeSource().getLocation().getPath().substring(0,Login.class.getProtectionDomain().getCodeSource().getLocation().getPath().indexOf("Geolocalizzata")+14)+"/src/immagini/Blank.jpg"));
            } catch (IOException ex) {
            }
            ImageIcon icon = new ImageIcon(image.getScaledInstance(width, height, Image.SCALE_SMOOTH));
            return icon;
        }
         return null;
    }
    //permette di visualizzare la versione scalata di una certa immagine
    public ImageIcon aggiungiFotoAllaGalleriaCondivisa(Integer i, Integer width, Integer height){
        try {
            if (!fotoGalleriaVisualizzata.get(0).isBlank()) {
                BufferedImage image = null;
                try {
                    image = ImageIO.read(new File(Login.class.getProtectionDomain().getCodeSource().getLocation().getPath().substring(0,Login.class.getProtectionDomain().getCodeSource().getLocation().getPath().indexOf("Geolocalizzata")+14)+"/src/immagini/" + fotoGalleriaVisualizzata.get(i) + ".jpg"));
                } catch (IOException ex) {
                }
                ImageIcon icon = new ImageIcon(image.getScaledInstance(width, height, Image.SCALE_SMOOTH));
                return icon;
            }
        } catch (IndexOutOfBoundsException exception){
        }
        return null;
    }
    //recupera un'immagine contenuta in una galleria condivisa e la imposta come immagine rappresentativa della galleria nella schermata utente
    public ImageIcon getCopertinaGalleriaCondivisa(Integer codGC){
        try {
            return aggiungiFotoAllaGalleria(galleriaCondivisaDAO.recuperoCopertinaGalleriaCondivisa(codGC,utenteLoggato.getNicknameUtente()), 300, 200);
        } catch (NullPointerException e){
        }
        return null;
    }


//METODI PER IL FILTRAGGIO DELLE FOTO E LA GESTIONE DI FOTO FILTRATE
    //applica un filtro per luogo e ritorna l'elenco di foto scattate in quel luogo
    public ArrayList<Fotografia> filtraFotoPerLuogo(String nomeUtente, String nomeLuogo){
        ArrayList<Fotografia> fotoFiltrate=new ArrayList<>();
        ResultSet elencoFoto=fotografiaDAO.filtraFotoPerLuogo(nomeUtente, nomeLuogo);
        try{
            while(elencoFoto.next()){
                Utente u= new Utente(elencoFoto.getString(6));
                Fotografia f=new Fotografia(elencoFoto.getString(5),elencoFoto.getString(2),true,u);
                f.setIdfoto(elencoFoto.getInt(1));
                f.setDimensioni(elencoFoto.getInt(4),elencoFoto.getInt(3));
                f.setDataScatto(elencoFoto.getDate(7));
                fotoFiltrate.add(f);
            }
        }catch (SQLException e){
            e.printStackTrace();
        }

        return fotoFiltrate;
    }
    //applica un filtro per soggetto e ritorna l'elenco di foto che lo rappresentano
    public ArrayList<Fotografia> filtraFotoPerSoggetto(String nomeUtente, String nomeSoggetto,String tipoSoggetto){
        ArrayList<Fotografia> fotoFiltrate=new ArrayList<>();
        ResultSet elencoFoto=fotografiaDAO.filtraFotoPerSoggetto(nomeUtente, nomeSoggetto, tipoSoggetto);
        try{
            while(elencoFoto.next()){
                Utente u= new Utente(elencoFoto.getString(6));
                Fotografia f=new Fotografia(elencoFoto.getString(5),elencoFoto.getString(2),true,u);
                f.setIdfoto(elencoFoto.getInt(1));
                f.setDimensioni(elencoFoto.getInt(4),elencoFoto.getInt(3));
                f.setDataScatto(elencoFoto.getDate(7));
                fotoFiltrate.add(f);
            }
        }catch (SQLException e){
            e.printStackTrace();
        }

        return fotoFiltrate;
    }
    //crea l'elenco di foto filtrate
    public void setFotoFiltrate(ArrayList<Fotografia> f){
        fotoFiltrate=new ArrayList<>();
        fotoFiltrate=f;
    }
    //restituisce il numero di foto recuperate dopo l'applicazione di un filtro
    public Integer getNumeroFotoFiltrate(){
        return fotoFiltrate.size();
    }
    //restituisce l'Iesima foto recuperata dopo l'applicazione di un filtro
    public Fotografia getFotoFiltrata(Integer i){
        return fotoFiltrate.get(i);
    }
    //recupera una il nome di una fotografia che ha come soggetto uno dei 3 luoghi più immortalati
    public String top3LuoghiImmortalati(String nomeLuogo){
        ResultSet foto=fotografiaDAO.top3LuoghiImmortalati(nomeLuogo);
        try {
            while(foto.next())
                return foto.getString(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    //recupera i nomi dei 3 luoghi più immortalati
    public ArrayList<String> getNometop3LuoghiImmortalati(){
        ArrayList<String> nomeFoto=new ArrayList<>();
        ResultSet elencoFoto;
        try {
            elencoFoto = soggettoDAO.top3LuoghiImmortalati();
            while(elencoFoto.next())
                nomeFoto.add(elencoFoto.getString(1));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return nomeFoto;
    }


//METODI PER LA GESTIONE DELL'INTERAZIONE CON IL DATABASE
    public Boolean controlloEsistenzaUtenteLoggatoDB(String nickname, String password){
        return(utenteDAO.controlloEsistenzaUtente(nickname, password));
    }
    public Boolean controlloEsistenzaUtenteDB(String nickname){
        return(utenteDAO.controlloEsistenzaUtente(nickname,null));
    }
    public Boolean registrazioneUtenteDB(){
        return(utenteDAO.registrazioneUtente(utenteLoggato.getNomeUtente(), utenteLoggato.getCognomeUtente(), utenteLoggato.getNicknameUtente(), utenteLoggato.getPasswordUtente()));
    }
    public void inserimentoFotografiaDB(){
        fotografiaDAO.inserimentoFoto(fotografiaInserita.getDispositivoFotografia(),fotografiaInserita.getAltezzaFotografia(),fotografiaInserita.getLarghezzaFotografia(),fotografiaInserita.getNomeFotografia(),fotografiaInserita.getFotografo(),fotografiaInserita.getLuogoScattoFotografia().getNomeLuogo(),fotografiaInserita.getVisibilitaFotografia(),fotografiaInserita.getDataScatto());
        fotografiaInserita.setIdfoto(fotografiaDAO.associaCodiceFoto());
    }
    public void inserimentoFotografiaInGalleriaPersonaleDB(){
        galleriaPersonaleDAO.inserimentoFotografiaInGalleria(fotografiaInserita.getIdFoto(),utenteLoggato.getCodGP());
    }
    public void inserimentoFotografiaInGalleriaCondivisaDB(Integer codFoto, Integer codGC){
        galleriaCondivisaDAO.inserimentoFotografiaInGalleria(codFoto, codGC);
    }
    public void inserimentoLuogoDB(String nomeLuogo, Double latitudine, Double longitudine){
            luogoDAO.inserimentoLuogo(latitudine, longitudine, nomeLuogo);}
    public Integer controlloEsistenzaLuogoDB(String nomeLuogo, Double latitudine, Double longitudine){return luogoDAO.controlloEsistenzaLuogo(nomeLuogo,latitudine,longitudine, this);}
    public Boolean controlloEsistenzaSoggettoDB(String nomeSoggetto, String tipoSoggetto){
        return soggettoDAO.controlloEsistenzaSoggetto(nomeSoggetto,tipoSoggetto);
    }
    public void recuperoNomiFotografieGalleriaCondivisaDB(){
        fotoGalleriaVisualizzata = new ArrayList<>();
        fotoGalleriaVisualizzata= galleriaCondivisaDAO.recuperoNomiFotoGalleriaCondivisa(galleriaVisualizzata, utenteLoggato.getNicknameUtente());
    }
    public void rimuoviFotografiaDaGalleriaPersonaleDB(Integer codFoto){
        galleriaPersonaleDAO.rimuoviFotografiaDaGalleria(codFoto, utenteLoggato.getCodGP());
    }
    public void rimuoviFotografiaDaGalleriaCondivisaDB(Integer codFoto){
        galleriaCondivisaDAO.rimuoviFotografiaDaGalleria(codFoto,Integer.valueOf(galleriaVisualizzata.substring(galleriaVisualizzata.lastIndexOf("#")+1)),utenteLoggato.getNicknameUtente());
    }
    public Boolean controlloEsistenzaGalleriaCondivisaDB(String codGC, String nickname){
        return (galleriaCondivisaDAO.controlloEsistenzaGalleriaCondivisa(codGC, nickname));
    }
    public void recuperoGalleriaCondivisaDB(String nickUtenteLoggato) {
        Integer i = 0;
        ArrayList<Utente> utentiPartecipanti=new ArrayList<>();
        //recupera tutti gli utenti di una certa galleria
        ResultSet elencoUtenti=galleriaCondivisaDAO.recuperoUtentiPartecipantiGalleriaCondivisa(galleriaVisualizzata);
        try{
            while(elencoUtenti.next()){
                Utente utente = new Utente(elencoUtenti.getString(1));
                utentiPartecipanti.add(utente);
            }
        }catch (SQLException e ){
            e.printStackTrace();
        }
        galleriaCondivisaVisualizzata = new GalleriaCondivisa(galleriaVisualizzata, utentiPartecipanti.get(0), utentiPartecipanti.get(1));
        galleriaCondivisaVisualizzata.setUtentiPartecipanti(utentiPartecipanti);
        galleriaCondivisaVisualizzata.setIdGalleria(galleriaCondivisaDAO.associaCodiceGalleria(galleriaVisualizzata));
        //per ogni utente recupera tutte le foto da lui scattate e contenute in quella galleria
            ResultSet fotografieGalleria = galleriaCondivisaDAO.recuperoFotografie(Integer.parseInt(galleriaCondivisaVisualizzata.getNomeGalleria().substring(galleriaCondivisaVisualizzata.getNomeGalleria().lastIndexOf('#')+1)), nickUtenteLoggato);
            try {
                while (fotografieGalleria.next()) {
                    Utente utente = new Utente(fotografieGalleria.getString(4));
                    Fotografia fotografia = new Fotografia(fotografieGalleria.getString(2), fotografieGalleria.getString(3), true, utente);
                    fotografia.setIdfoto(fotografieGalleria.getInt(1));
                    fotografia.setDimensioni(fotografieGalleria.getInt(6), fotografieGalleria.getInt(5));
                    fotografia.setDataScatto(fotografieGalleria.getDate(7));
                    Luogo luogoScatto = new Luogo(fotografieGalleria.getString(8), fotografieGalleria.getDouble(9), fotografieGalleria.getDouble(10), fotografia);
                    luogoScatto.setNomeLuogo(fotografieGalleria.getString(8));
                    //per ogni foto recupera tutti i soggetti rappresentati
                    ResultSet elencoSoggetti = soggettoDAO.recuperoSoggettiFotografia(fotografia.getIdFoto());
                    try {
                        while (elencoSoggetti.next()) {
                            if (elencoSoggetti.getString(2).equals("utente")) {
                                Utente utente1 = new Utente(elencoSoggetti.getString(3));
                                Soggetto soggetto = new Soggetto(utente1, fotografia);
                                soggetto.setCodiceSoggetto(elencoSoggetti.getInt(1));
                            } else if (elencoSoggetti.getString(2).equals("luogo")) {
                                Luogo luogo = new Luogo(elencoSoggetti.getString(4));
                                Soggetto soggetto = new Soggetto(luogo, fotografia);
                                soggetto.setCodiceSoggetto(elencoSoggetti.getInt(1));
                            } else {
                                Soggetto soggetto = new Soggetto(elencoSoggetti.getString(2), fotografia);
                                soggetto.setCodiceSoggetto(elencoSoggetti.getInt(1));
                            }
                        }
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                    galleriaCondivisaVisualizzata.addFotoInGalleria(fotografia);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
    }
    public void inserimentoSoggettiDB(String elencoSoggetti){
        ArrayList<String> soggetti = new ArrayList<>(List.of(elencoSoggetti.split(", ")));
        Integer i=0;
        //per ogni soggetto ne controlla l'esistenza e lo inserisce tra i soggetti della foto da inserire
        while(i<soggetti.size()){
            if (!soggettoDAO.controlloEsistenzaSoggetto(soggetti.get(i),tipiSoggettiFotografiaInserita.get(i))) {
                soggettoDAO.inserimentoSoggetto(soggetti.get(i), tipiSoggettiFotografiaInserita.get(i));
                soggettoDAO.associaSoggettoFotografia(soggetti.get(i),tipiSoggettiFotografiaInserita.get(i),fotografiaInserita.getIdFoto());

            }
            else
                soggettoDAO.associaSoggettoFotografia(soggetti.get(i),tipiSoggettiFotografiaInserita.get(i),fotografiaInserita.getIdFoto());
                i++;
        }
    }
    public void creaGalleriaCondivisaDB(String nome, ArrayList<String> utenti){
        galleriaCondivisaDAO.creazioneGalleriaCondivisa(nome,utenti);
    }


    public Controller(){
    }
}
