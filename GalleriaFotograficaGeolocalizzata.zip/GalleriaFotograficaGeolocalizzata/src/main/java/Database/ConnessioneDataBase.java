package Database;

import javax.swing.*;
import java.sql.*;
public class ConnessioneDataBase {
    private static ConnessioneDataBase instance;
    public Connection connection = null;
    private String nome = "postgres";
    private String password = "SUPERUSER";
    private String url = "jdbc:postgresql://localhost:5432/galleriafotograficacondivisa";
    private String driver = " org.postgresql.Driver";

    private ConnessioneDataBase() throws SQLException {
        try {
            connection = DriverManager.getConnection(url, nome, password);
            JOptionPane.showMessageDialog(null, "Database trovato");

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Database non trovato");
            e.printStackTrace();
        }
    }

    public static ConnessioneDataBase getInstance() throws SQLException {
        if (instance==null) {
            instance = new ConnessioneDataBase();
        } else if (instance.connection.isClosed()){
            instance = new ConnessioneDataBase();
        }
        return instance;
    }
}

