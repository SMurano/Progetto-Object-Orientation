package ImplementazionePostgresDAO;

import DAO.GalleriaDAO;
import Database.ConnessioneDataBase;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ImplementazioneGalleriaPersonaleDAO implements GalleriaDAO {
    private Connection connection;
    public ImplementazioneGalleriaPersonaleDAO() {
        try {
            connection = ConnessioneDataBase.getInstance().connection;
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    @Override
    public Integer associaCodiceGalleria(String nomeGalleria){
        PreparedStatement associaCodiceGalleriaPS;
        ResultSet codiceGalleria;
        Integer codGP = -1;
        try {
            associaCodiceGalleriaPS = connection.prepareStatement("SELECT codgp FROM galleriafotograficacondivisa.galleriapersonale WHERE nomegp = '"+nomeGalleria+"'");
            codiceGalleria = associaCodiceGalleriaPS.executeQuery();
            if (codiceGalleria.next())
                codGP=codiceGalleria.getInt(1);
        } catch (SQLException e){
        }
        return codGP;
    }
    public void inserimentoFotografiaInGalleria(Integer codFoto, Integer codGP) {
        PreparedStatement inserimentoFotografiaInGalleriaPersonalePS;
        try {
            inserimentoFotografiaInGalleriaPersonalePS = connection.prepareStatement("INSERT INTO galleriafotograficacondivisa.CONTENIMENTO VALUES('"+codFoto+"','"+codGP+"')");
            inserimentoFotografiaInGalleriaPersonalePS.executeQuery();
        } catch (SQLException e){
        }
    }

    public ResultSet recuperoFotografie(String nickname) {
        PreparedStatement recuperoFotografieUtentePS;
        ResultSet elencoFoto=null;
        try {
            recuperoFotografieUtentePS = connection.prepareStatement("SELECT * FROM galleriafotograficacondivisa.Foto NATURAL JOIN galleriafotograficacondivisa.Luogo NATURAL JOIN galleriafotograficacondivisa.Contenimento  WHERE NFotografo='" + nickname + "'");
            elencoFoto = recuperoFotografieUtentePS.executeQuery();
        } catch (SQLException e){
        }
        return elencoFoto;
    }
    @Override
    public void rimuoviFotografiaDaGalleria(Integer codFoto,Integer codGP) {
        PreparedStatement rimuoviFotografiaDaGalleriaPersonalePS;
        try {
            rimuoviFotografiaDaGalleriaPersonalePS = connection.prepareStatement("DELETE FROM galleriafotograficacondivisa.contenimento WHERE codFoto='"+codFoto+"' AND codGP='"+codGP+"'");
            rimuoviFotografiaDaGalleriaPersonalePS.executeQuery();
        }catch (SQLException e){
        }
    }

}
