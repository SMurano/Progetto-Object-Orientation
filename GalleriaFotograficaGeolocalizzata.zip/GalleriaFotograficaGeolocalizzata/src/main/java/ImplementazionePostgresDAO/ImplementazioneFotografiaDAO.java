package ImplementazionePostgresDAO;

import DAO.FotografiaDAO;
import Database.ConnessioneDataBase;

import javax.xml.transform.Result;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ImplementazioneFotografiaDAO implements FotografiaDAO {
    private Connection connection;
    public ImplementazioneFotografiaDAO() {
        try {
            connection = ConnessioneDataBase.getInstance().connection;
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //associa all'ultima fotografia inserita il corrispettivo id
    //i codici vengono generati dal database, per questo vanno associati dopo l'inserimento della galleria nel database
    public Integer associaCodiceFoto(){
        PreparedStatement associaCodiceFotoPS;
        ResultSet codiceFoto;
        Integer codFoto = null;
        try {
            associaCodiceFotoPS = connection.prepareStatement("SELECT codfoto FROM galleriafotograficacondivisa.FOTO WHERE codfoto>= ALL (SELECT codfoto FROM galleriafotograficacondivisa.FOTO)");
            codiceFoto = associaCodiceFotoPS.executeQuery();
            if (codiceFoto.next())
                codFoto=codiceFoto.getInt(1);
        } catch (SQLException e){
            e.printStackTrace();
        }
        return codFoto;
    }


    //inserisce una fotografia nel database
    //i dati non necessari che non vengono forniti vengono settati a null
    @Override
    public void inserimentoFoto(String dispositivo, Integer altezza, Integer larghezza, String nome, String fotografo, String nomeLuogo, String visibilita, Date data) {
        PreparedStatement inserimentoFotoPS=null;
        try {
            if ((altezza!=null && larghezza!=null) && data!=null)
                inserimentoFotoPS = connection.prepareStatement("INSERT INTO galleriafotograficacondivisa.Foto VALUES (DEFAULT,'" + dispositivo + "','" + altezza + "','" + larghezza + "','" + nome + "','" + fotografo + "','" + nomeLuogo + "','" + visibilita + "','"+ data + "')");
            if ((altezza==null || larghezza==null) && data!=null)
                inserimentoFotoPS = connection.prepareStatement("INSERT INTO galleriafotograficacondivisa.Foto VALUES (DEFAULT,'" + dispositivo + "', NULL , NULL ,'" + nome + "','" + fotografo + "','" + nomeLuogo + "','" + visibilita + "','"+ data + "')");
            if ((altezza!=null && larghezza!=null) && data==null)
                inserimentoFotoPS = connection.prepareStatement("INSERT INTO galleriafotograficacondivisa.Foto VALUES (DEFAULT,'" + dispositivo + "','" + altezza + "','" + larghezza + "','" + nome + "','" + fotografo + "','" + nomeLuogo + "','" + visibilita + "',NULL)");
            if ((altezza==null || larghezza==null) && data==null)
                inserimentoFotoPS = connection.prepareStatement("INSERT INTO galleriafotograficacondivisa.Foto VALUES (DEFAULT,'" + dispositivo + "', NULL , NULL ,'" + nome + "','" + fotografo + "','" + nomeLuogo + "','" + visibilita + "',NULL)");
            inserimentoFotoPS.executeQuery();
        } catch (SQLException e) {
        }
    }

    //recupera tutti i soggetti di una data foto
    public ResultSet recuperoSoggettiFoto(String nickname,Integer codFoto) {
        PreparedStatement recuperoSoggettiFotoPS;
        ResultSet soggettiFoto;
        try {
            recuperoSoggettiFotoPS = connection.prepareStatement("SELECT codSoggetto,tipo,nickSoggetto,nomeSoggetto FROM galleriafotograficacondivisa.Foto NATURAL JOIN galleriafotograficacondivisa.Afferenza NATURAL JOIN galleriafotograficacondivisa.Soggetto  WHERE NFotografo='" + nickname + "' AND CodFoto=" + codFoto);
            soggettiFoto = recuperoSoggettiFotoPS.executeQuery();
            return soggettiFoto;
        } catch (SQLException e) {
            return null;
        }
    }

    //rende una foto pubblica
    public void rendiFotoPubblica(Integer codFoto){
        PreparedStatement rendiFotoPubblicaPS;
        try {
            rendiFotoPubblicaPS=connection.prepareStatement("UPDATE galleriafotograficacondivisa.FOTO SET TipoFoto='pubblico' WHERE codFoto="+codFoto);
            rendiFotoPubblicaPS.executeQuery();
        } catch (SQLException e) {
        }
    }

    //rende una foto privata
    public void privatizzaFoto(Integer codFoto){
        PreparedStatement privatizzafotoPS;
        try{
            privatizzafotoPS=connection.prepareStatement("UPDATE galleriafotograficacondivisa.FOTO SET TipoFoto='privato' WHERE codFoto="+codFoto);
            privatizzafotoPS.executeQuery();
        }catch(SQLException e){
        }

    }

    //recupera le fotografie di un certo utente filtrate per luogo di scatto
    public ResultSet filtraFotoPerLuogo(String nomeUtente, String nomeLuogo){
        PreparedStatement filtraFotoPerLuogoPS;
        ResultSet elencoFoto=null;
        try{
            filtraFotoPerLuogoPS=connection.prepareStatement("SELECT F.codFoto, F.Dispositivo, F.DimAltezza, F.DimLarghezza, F.NomeFoto, F.Nfotografo, F.DataScatto,GC.NomeGC" +
                    "   FROM galleriafotograficacondivisa.FOTO AS F " +
                    "   JOIN galleriafotograficacondivisa.CONDIVISIONE AS CO " +
                    "   ON F.CodFoto=CO.CodFoto" +
                    "   JOIN galleriafotograficacondivisa.GALLERIACONDIVISA AS GC" +
                    "   ON CO.CodGC=GC.CodGC" +
                    "   JOIN galleriafotograficacondivisa.PARTECIPAZIONE AS P" +
                    "   ON GC.CODGC=P.CODGC" +
                    "   WHERE F.NomeLuogo='"+nomeLuogo+"' AND P.nickname='"+nomeUtente+"'" +
                    "" +
                    "   UNION" +
                    "" +
                    "   SELECT F.codFoto, F.Dispositivo, F.DimAltezza, F.DimLarghezza, F.NomeFoto, F.Nfotografo, F.DataScatto,GP.NomeGP" +
                    "   FROM galleriafotograficacondivisa.FOTO AS F " +
                    "   JOIN galleriafotograficacondivisa.CONTENIMENTO AS C " +
                    "   ON F.codFoto=C.codFoto " +
                    "   JOIN galleriafotograficacondivisa.GALLERIAPERSONALE AS GP" +
                    "   ON C.CodGP=GP.CodGP " +
                    "   WHERE GP.NomeGP=CONCAT('GALLERIA DI ','"+nomeUtente+"'"+") AND F.NomeLuogo='"+nomeLuogo+"'");
            elencoFoto=filtraFotoPerLuogoPS.executeQuery();

        }catch (SQLException e){
        }
        return elencoFoto;
    }

    //recupera le fotografie di un certo utente filtrate per soggetto rappresentato
    public ResultSet filtraFotoPerSoggetto(String nomeUtente, String nomeSoggetto,String tipoSoggetto){
        PreparedStatement filtraFotoPerSoggettoPS = null;
        ResultSet elencoFoto=null;
        try{
            if (tipoSoggetto.equals("utente"))
                filtraFotoPerSoggettoPS=connection.prepareStatement("SELECT F.codFoto, F.Dispositivo, F.DimAltezza, F.DimLarghezza, F.NomeFoto, F.Nfotografo, F.DataScatto, GC.NomeGC " +
                    "FROM galleriafotograficacondivisa.FOTO AS F " +
                    "JOIN galleriafotograficacondivisa.CONDIVISIONE AS CO " +
                    "ON F.CodFoto=CO.CodFoto " +
                    "JOIN galleriafotograficacondivisa.GALLERIACONDIVISA AS GC " +
                    "ON CO.CodGC=GC.CodGC " +
                    "JOIN galleriafotograficacondivisa.PARTECIPAZIONE AS P " +
                    "ON GC.CODGC=P.CODGC " +
                    "JOIN galleriafotograficacondivisa.AFFERENZA AS A " +
                    "ON F.CodFoto=A.CodFoto " +
                    "JOIN galleriafotograficacondivisa.SOGGETTO AS S " +
                    "ON A.CodSoggetto=S.CodSoggetto " +
                    "WHERE (S.NickSoggetto='"+nomeSoggetto+"' AND S.Tipo='"+tipoSoggetto+"') AND P.nickname='"+nomeUtente+"' " +
                    " " +
                    "UNION" +
                    " " +
                    "SELECT F.codFoto, F.Dispositivo, F.DimAltezza, F.DimLarghezza, F.NomeFoto, F.Nfotografo, F.DataScatto,GP.NomeGP " +
                    "FROM galleriafotograficacondivisa.FOTO AS F " +
                    "JOIN galleriafotograficacondivisa.CONTENIMENTO AS C " +
                    "ON F.codFoto=C.codFoto " +
                    "JOIN galleriafotograficacondivisa.GALLERIAPERSONALE AS GP " +
                    "ON C.CodGP=GP.CodGP " +
                    "JOIN galleriafotograficacondivisa.AFFERENZA AS A " +
                    "ON F.CodFoto=A.CodFoto " +
                    "JOIN galleriafotograficacondivisa.SOGGETTO AS S " +
                    "ON A.CodSoggetto=S.CodSoggetto " +
                    "WHERE GP.NomeGP=CONCAT('GALLERIA DI ','"+nomeUtente+"') AND (S.NickSoggetto='"+nomeSoggetto+"' AND S.Tipo='"+tipoSoggetto+"')");
            if (tipoSoggetto.equals("luogo"))
                filtraFotoPerSoggettoPS=connection.prepareStatement("SELECT F.codFoto, F.Dispositivo, F.DimAltezza, F.DimLarghezza, F.NomeFoto, F.Nfotografo, F.DataScatto, GC.NomeGC " +
                        "FROM galleriafotograficacondivisa.FOTO AS F " +
                        "JOIN galleriafotograficacondivisa.CONDIVISIONE AS CO " +
                        "ON F.CodFoto=CO.CodFoto " +
                        "JOIN galleriafotograficacondivisa.GALLERIACONDIVISA AS GC " +
                        "ON CO.CodGC=GC.CodGC " +
                        "JOIN galleriafotograficacondivisa.PARTECIPAZIONE AS P " +
                        "ON GC.CODGC=P.CODGC " +
                        "JOIN galleriafotograficacondivisa.AFFERENZA AS A " +
                        "ON F.CodFoto=A.CodFoto " +
                        "JOIN galleriafotograficacondivisa.SOGGETTO AS S " +
                        "ON A.CodSoggetto=S.CodSoggetto " +
                        "WHERE (S.NomeSoggetto='"+nomeSoggetto+"' AND S.Tipo='"+tipoSoggetto+"') AND P.nickname='"+nomeUtente+"' " +
                        " " +
                        "UNION" +
                        " " +
                        "SELECT F.codFoto, F.Dispositivo, F.DimAltezza, F.DimLarghezza, F.NomeFoto, F.Nfotografo, F.DataScatto,GP.NomeGP " +
                        "FROM galleriafotograficacondivisa.FOTO AS F " +
                        "JOIN galleriafotograficacondivisa.CONTENIMENTO AS C " +
                        "ON F.codFoto=C.codFoto " +
                        "JOIN galleriafotograficacondivisa.GALLERIAPERSONALE AS GP " +
                        "ON C.CodGP=GP.CodGP " +
                        "JOIN galleriafotograficacondivisa.AFFERENZA AS A " +
                        "ON F.CodFoto=A.CodFoto " +
                        "JOIN galleriafotograficacondivisa.SOGGETTO AS S " +
                        "ON A.CodSoggetto=S.CodSoggetto " +
                        "WHERE GP.NomeGP=CONCAT('GALLERIA DI ','"+nomeUtente+"') AND (S.NomeSoggetto='"+nomeSoggetto+"' AND S.Tipo='"+tipoSoggetto+"')");
                if (!tipoSoggetto.equals("utente") && !tipoSoggetto.equals("luogo"))
                    filtraFotoPerSoggettoPS=connection.prepareStatement("SELECT F.codFoto, F.Dispositivo, F.DimAltezza, F.DimLarghezza, F.NomeFoto, F.Nfotografo, F.DataScatto, GC.NomeGC " +
                            "FROM galleriafotograficacondivisa.FOTO AS F " +
                            "JOIN galleriafotograficacondivisa.CONDIVISIONE AS CO " +
                            "ON F.CodFoto=CO.CodFoto " +
                            "JOIN galleriafotograficacondivisa.GALLERIACONDIVISA AS GC " +
                            "ON CO.CodGC=GC.CodGC " +
                            "JOIN galleriafotograficacondivisa.PARTECIPAZIONE AS P " +
                            "ON GC.CODGC=P.CODGC " +
                            "JOIN galleriafotograficacondivisa.AFFERENZA AS A " +
                            "ON F.CodFoto=A.CodFoto " +
                            "JOIN galleriafotograficacondivisa.SOGGETTO AS S " +
                            "ON A.CodSoggetto=S.CodSoggetto " +
                            "WHERE (S.Tipo='"+tipoSoggetto+"') AND P.nickname='"+nomeUtente+"' " +
                            " " +
                            "UNION" +
                            " " +
                            "SELECT F.codFoto, F.Dispositivo, F.DimAltezza, F.DimLarghezza, F.NomeFoto, F.Nfotografo, F.DataScatto,GP.NomeGP " +
                            "FROM galleriafotograficacondivisa.FOTO AS F " +
                            "JOIN galleriafotograficacondivisa.CONTENIMENTO AS C " +
                            "ON F.codFoto=C.codFoto " +
                            "JOIN galleriafotograficacondivisa.GALLERIAPERSONALE AS GP " +
                            "ON C.CodGP=GP.CodGP " +
                            "JOIN galleriafotograficacondivisa.AFFERENZA AS A " +
                            "ON F.CodFoto=A.CodFoto " +
                            "JOIN galleriafotograficacondivisa.SOGGETTO AS S " +
                            "ON A.CodSoggetto=S.CodSoggetto " +
                            "WHERE GP.NomeGP=CONCAT('GALLERIA DI ','"+nomeUtente+"') AND S.Tipo='"+tipoSoggetto+"'");
            elencoFoto=filtraFotoPerSoggettoPS.executeQuery();

        }catch (SQLException e){
        }
        return elencoFoto;
    }

    //recupera i nomi dei 3 luoghi più immortalati ed il codice di una fotografia che li rapppresenti
    public ResultSet top3LuoghiImmortalati(String nomeLuogo){
        PreparedStatement top3LuoghiImmortalatiPS;
        ResultSet luoghi = null;
        try {
            top3LuoghiImmortalatiPS=connection.prepareStatement("SELECT CONCAT(nomefoto,codFoto) FROM galleriafotograficacondivisa.top3luoghi NATURAL JOIN galleriafotograficacondivisa.soggetto NATURAL JOIN galleriafotograficacondivisa.afferenza NATURAL JOIN galleriafotograficacondivisa.foto WHERE nomeSoggetto='"+nomeLuogo+"' ORDER BY Count DESC LIMIT 1");
            luoghi=top3LuoghiImmortalatiPS.executeQuery();
        } catch (SQLException e) {
        }
        return luoghi;
    }
}
