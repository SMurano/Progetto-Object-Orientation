package ImplementazionePostgresDAO;

import DAO.UtenteDAO;
import Database.ConnessioneDataBase;
import javax.swing.*;
import java.sql.*;
import java.util.ArrayList;


public class ImplementazioneUtenteDAO implements UtenteDAO {

    private Connection connection;
    public ImplementazioneUtenteDAO(){
        try {
            connection = ConnessioneDataBase.getInstance().connection;
    } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Boolean controlloEsistenzaUtente(String nickname, String password) {
        PreparedStatement checkEsistenzaUtentePS;
        ResultSet resultSet;
        try {
            if(password!=null)
                checkEsistenzaUtentePS = connection.prepareStatement("SELECT Nickname FROM galleriafotograficacondivisa.utente WHERE Nickname= '"+nickname+"' AND Pass= '"+password+"'");
            else
                checkEsistenzaUtentePS = connection.prepareStatement("SELECT Nickname FROM galleriafotograficacondivisa.utente WHERE Nickname= '"+nickname+"' ");
            resultSet= checkEsistenzaUtentePS.executeQuery();
            if (!resultSet.next()) {
                JOptionPane.showMessageDialog(null, "utente inesistente");
                return false;
            }
        } catch (SQLException e){
                JOptionPane.showMessageDialog(null, "utente non trovato");
            }
        return true;
    }


    public Boolean registrazioneUtente(String nome, String cognome, String nickname, String password) {
    PreparedStatement registrazioneUtentePS;
    try {
        registrazioneUtentePS = connection.prepareStatement("INSERT INTO galleriafotograficacondivisa.UTENTE VALUES ('"+nome+"','"+cognome+"','"+nickname+"','"+password+"',DEFAULT)");
        registrazioneUtentePS.executeQuery();
    } catch (SQLException e) {
        if (e.getSQLState().equals(String.valueOf(23505))) {
            JOptionPane.showMessageDialog(null, "Utente già esistente ");
            return false;
        } else if (e.getSQLState().equals(String.valueOf(23514)) || e.getSQLState().equals(String.valueOf(22001))) {
            JOptionPane.showMessageDialog(null,"Dati inseriti non validi");
            return false;
        }
    }
    return true;
    }

    public ArrayList<String> recuperoGallerieACuiPartecipi(String nickname) {
        PreparedStatement recuperoGallerieACuiPartecipiPS;
        ResultSet resultSet;
        ArrayList<String> nomiGallerieACuiPartecipi = new ArrayList<>();
        try {
            recuperoGallerieACuiPartecipiPS = connection.prepareStatement("SELECT nomegc FROM galleriafotograficacondivisa.galleriacondivisa AS GC JOIN galleriafotograficacondivisa.partecipazione AS P ON GC.codGC=P.CodGC WHERE P.Nickname='" + nickname + "'");
            resultSet = recuperoGallerieACuiPartecipiPS.executeQuery();
            while (resultSet.next())
                nomiGallerieACuiPartecipi.add(resultSet.getString(1));
        } catch (SQLException e){
        }
        return nomiGallerieACuiPartecipi;
    }
}
