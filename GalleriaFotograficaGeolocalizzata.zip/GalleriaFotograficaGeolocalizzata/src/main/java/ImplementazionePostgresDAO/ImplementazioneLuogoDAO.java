package ImplementazionePostgresDAO;

import DAO.LuogoDAO;
import Database.ConnessioneDataBase;
import Controller.Controller;
import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ImplementazioneLuogoDAO implements LuogoDAO {
    private Connection connection;

    public ImplementazioneLuogoDAO() {
        try {
            connection = ConnessioneDataBase.getInstance().connection;
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void inserimentoLuogo(Double latitudine, Double longitudine, String nome) {
        PreparedStatement inserimentoLuogoPS;
        try {
            if (latitudine==null || longitudine==null)
                inserimentoLuogoPS = connection.prepareStatement("INSERT INTO galleriafotograficacondivisa.Luogo VALUES ( NULL , NULL ,'" + nome + "')");
            else
                inserimentoLuogoPS = connection.prepareStatement("INSERT INTO galleriafotograficacondivisa.Luogo VALUES ('" + latitudine + "','" + longitudine + "','" + nome + "')");
            inserimentoLuogoPS.executeQuery();
        } catch (SQLException e) {
        }
    }

    @Override
    public Integer controlloEsistenzaLuogo(String nome, Double latitudine, Double longitudine, Controller controller) {
        PreparedStatement controlloEsistenzaLuogoPS;
        ResultSet resultSet;
        try {

            if(latitudine==null || longitudine==null){
                controlloEsistenzaLuogoPS = connection.prepareStatement("SELECT NomeLuogo, Latitudine, Longitudine FROM galleriafotograficacondivisa.luogo WHERE Nomeluogo= '" + nome + "'");
                resultSet = controlloEsistenzaLuogoPS.executeQuery();
                if (resultSet.next()) {
                    controller.updateLuogoFotografiaInserita(resultSet.getDouble(2), resultSet.getDouble(3));
                    return 1;
                }
                else
                    return 0;
            }

            controlloEsistenzaLuogoPS = connection.prepareStatement("SELECT NomeLuogo, Latitudine, Longitudine FROM galleriafotograficacondivisa.luogo WHERE Nomeluogo= '" + nome + "' AND Latitudine= '" + latitudine + "' AND Longitudine= '" + longitudine + "'");
            resultSet = controlloEsistenzaLuogoPS.executeQuery();
            if (resultSet.next())
                return 1;

            controlloEsistenzaLuogoPS = connection.prepareStatement("SELECT NomeLuogo, Latitudine, Longitudine FROM galleriafotograficacondivisa.luogo WHERE Nomeluogo= '" + nome + "'");
            resultSet = controlloEsistenzaLuogoPS.executeQuery();
            if (resultSet.next()) {
                if (resultSet.getDouble(2) == latitudine && resultSet.getDouble(3) == longitudine)
                    return 1;
                if (resultSet.getString(2) == null || resultSet.getString(3) == null) {
                    controller.updateLuogoFotografiaInserita(resultSet.getDouble(2), resultSet.getDouble(3));
                    return 1;
                }
                if (resultSet.getDouble(2) != latitudine || resultSet.getDouble(3) != longitudine)
                    if (JOptionPane.showConfirmDialog(null, "Il luogo inserito ha coordinate " + resultSet.getDouble(2) + " X " + resultSet.getDouble(3) + " sostituire i valori?") == JOptionPane.YES_OPTION) {
                        controller.updateLuogoFotografiaInserita(resultSet.getDouble(2), resultSet.getDouble(3));
                        return 1;
                    }else {
                        JOptionPane.showMessageDialog(null,"Inserisci un nuovo nome");
                        return -1;
                    }
            }

            controlloEsistenzaLuogoPS = connection.prepareStatement("SELECT NomeLuogo, Latitudine, Longitudine FROM galleriafotograficacondivisa.luogo WHERE Latitudine= '" + latitudine + "' AND Longitudine= '" + longitudine + "'");
            resultSet = controlloEsistenzaLuogoPS.executeQuery();
            if (resultSet.next()){
                if (JOptionPane.showConfirmDialog(null, "il luogo localizzato dalle coordinate inserite e' " + resultSet.getString(1) + " , cambiare il nome del luogo?") == JOptionPane.YES_OPTION) {
                    nome = resultSet.getString(1);
                    controller.setNomeLuogoScattoFotografiaInserita(nome);
                    return 1;
                } else {
                    JOptionPane.showMessageDialog(null, "Cambia le coordinate del luogo (latitudine, longitudine)");
                    return -1;
                }
            }

            return 0;

        }catch(SQLException e){
            e.printStackTrace();
            return 0;
        }
    }

}

