package ImplementazionePostgresDAO;

import DAO.GalleriaDAO;
import Database.ConnessioneDataBase;
import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ImplementazioneGalleriaCondivisaDAO implements GalleriaDAO {
    private Connection connection;
    public ImplementazioneGalleriaCondivisaDAO() {
        try {
            connection = ConnessioneDataBase.getInstance().connection;
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void creazioneGalleriaCondivisa(String nome, ArrayList<String> utenti) {
        PreparedStatement inserimentoGalleriaCondivisaPS;
        ResultSet codiceGalleria= null;
        Integer CodGC=-1;
        Integer i = -1;
        String nicknameUtente;

        try {
            inserimentoGalleriaCondivisaPS = connection.prepareStatement("INSERT INTO galleriafotograficacondivisa.galleriaCondivisa VALUES (DEFAULT,'" + nome + "')");
            inserimentoGalleriaCondivisaPS.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        try{
            inserimentoGalleriaCondivisaPS = connection.prepareStatement("SELECT CODGC FROM galleriafotograficacondivisa.galleriaCondivisa WHERE CODGC>=ALL(SELECT CODGC FROM galleriafotograficacondivisa.galleriaCondivisa)");
            codiceGalleria = inserimentoGalleriaCondivisaPS.executeQuery();
            if (codiceGalleria.next())
            CodGC=codiceGalleria.getInt(1);
        }catch(SQLException e){
            e.printStackTrace();
        }

        while (i < (utenti.size()-1)) {
            i++;
            nicknameUtente = utenti.get(i);
            try {

                inserimentoGalleriaCondivisaPS = connection.prepareStatement("INSERT INTO galleriafotograficacondivisa.partecipazione VALUES('" + nicknameUtente + "','"+CodGC+"')");
                inserimentoGalleriaCondivisaPS.executeQuery();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    @Override
    public Integer associaCodiceGalleria(String nomeGalleria) {
        PreparedStatement associaCodiceGalleriaPS;
        ResultSet codiceGalleria;
        Integer codGC = -1;
        try {
            associaCodiceGalleriaPS = connection.prepareStatement("SELECT codgc FROM galleriafotograficacondivisa.galleriacondivisa WHERE nomegc='"+nomeGalleria+"' AND codgc>= ALL (SELECT codgc FROM galleriafotograficacondivisa.galleriacondivisa)");
            codiceGalleria = associaCodiceGalleriaPS.executeQuery();
            if (codiceGalleria.next())
                codGC=codiceGalleria.getInt(1);
        } catch (SQLException e){
            e.printStackTrace();
        }
        return codGC;
    }
    public String recuperoGalleriaInserita(String nickname) {
        PreparedStatement recuperoGalleriaInseritaPS;
        ResultSet nomeGalleriaInserita;
        String nomeGalleria = "";
        try {
            recuperoGalleriaInseritaPS = connection.prepareStatement("SELECT nomeGC FROM galleriafotograficacondivisa.galleriacondivisa WHERE codGC >=ALL (SELECT codGC FROM galleriafotograficacondivisa.galleriacondivisa)");
            nomeGalleriaInserita = recuperoGalleriaInseritaPS.executeQuery();
            if (nomeGalleriaInserita.next())
                nomeGalleria= nomeGalleriaInserita.getString(1);
        } catch (SQLException e){
        }
        return nomeGalleria;
    }
    public ArrayList<String> recuperoNomiFotoGalleriaCondivisa (String nomeGC,String utenteLoggato){
        PreparedStatement recuperoNomiFotoGalleriaCondivisaPS;
        ResultSet nomiFotografieGalleriaCondivisa;
        ArrayList<String> nomiFotografieGC= new ArrayList<>();
        try{
            recuperoNomiFotoGalleriaCondivisaPS = connection.prepareStatement("SELECT nomefoto,codFoto FROM galleriafotograficacondivisa.foto NATURAL JOIN galleriafotograficacondivisa.condivisione NATURAL JOIN galleriafotograficacondivisa.galleriacondivisa WHERE galleriacondivisa.nomegc='"+nomeGC+"'AND ElencoUtenti LIKE '%"+utenteLoggato+"%'");
            nomiFotografieGalleriaCondivisa = recuperoNomiFotoGalleriaCondivisaPS.executeQuery();
            while (nomiFotografieGalleriaCondivisa.next())
                nomiFotografieGC.add(nomiFotografieGalleriaCondivisa.getString(1)+nomiFotografieGalleriaCondivisa.getString(2));
        } catch (SQLException e){
        }
        return nomiFotografieGC;
    }
    public void inserimentoFotografiaInGalleria(Integer codFoto, Integer codGC) {
        PreparedStatement inserimentoFotografiaInGalleriaPersonalePS;
        try {
            inserimentoFotografiaInGalleriaPersonalePS = connection.prepareStatement("INSERT INTO galleriafotograficacondivisa.condivisione VALUES('"+codFoto+"','"+codGC+"')");
            inserimentoFotografiaInGalleriaPersonalePS.executeQuery();
        } catch (SQLException e){
            if (e.getSQLState().equals(String.valueOf(23505)))
                JOptionPane.showMessageDialog(null, "Hai già inserito questa foto in questa galleria");
        }
    }

    @Override
    public ResultSet recuperoFotografie(String nickname) {
        return null;
    }

    @Override
    public void rimuoviFotografiaDaGalleria(Integer codFoto, Integer codG) {

    }

    public void rimuoviFotografiaDaGalleria(Integer codFoto,Integer codGC,String nomeUtente) {
        PreparedStatement rimuoviFotografiaDaGalleriaCondivisaPS;
        try {
            rimuoviFotografiaDaGalleriaCondivisaPS = connection.prepareStatement("CALL galleriafotograficacondivisa.EliminaUtenteDaElenco('"+nomeUtente+"',"+codFoto+","+codGC+")");
            rimuoviFotografiaDaGalleriaCondivisaPS.executeQuery();
        }catch (SQLException e){
        }
    }
    public Boolean controlloEsistenzaGalleriaCondivisa(String nomeGC, String nickname){
        PreparedStatement controlloEsistenzaGalleriaCondivisaPS;
        ResultSet galleriaCondivisa;
        try {
            controlloEsistenzaGalleriaCondivisaPS = connection.prepareStatement("SELECT codGC FROM galleriafotograficacondivisa.galleriacondivisa WHERE nomeGC ='"+nomeGC+"'");
            galleriaCondivisa = controlloEsistenzaGalleriaCondivisaPS.executeQuery();
            if (galleriaCondivisa.next()) {
                return (controlloPartecipazioneGalleriaCondivisa(nomeGC,nickname));
            } else {
                JOptionPane.showMessageDialog(null, "Galleria inesistente");
                return false;
            }
        } catch (SQLException e){
            return false;
        }
    }
    public Boolean controlloPartecipazioneGalleriaCondivisa(String nomeGC, String nickname){
        PreparedStatement controlloPartecipazioneGalleriaCondivisaPS;
        ResultSet nomeUtente;
        try {
            controlloPartecipazioneGalleriaCondivisaPS = connection.prepareStatement("SELECT nickname FROM galleriafotograficacondivisa.galleriacondivisa NATURAL JOIN galleriafotograficacondivisa.partecipazione NATURAL JOIN galleriafotograficacondivisa.utente WHERE nickname='" + nickname + "' AND nomeGC='" + nomeGC + "'");
            nomeUtente = controlloPartecipazioneGalleriaCondivisaPS.executeQuery();
            if (nomeUtente.next())
                return true;
            else {
                JOptionPane.showMessageDialog(null, "Non partecipi a quella galleria");
                return false;
            }
        } catch (SQLException e){
            return false;
        }
    }
    public ResultSet recuperoUtentiPartecipantiGalleriaCondivisa (String nomeGC) {
        PreparedStatement recuperoUtentiPartecipantiPS;
        ResultSet elencoUtenti=null;
        try {
            recuperoUtentiPartecipantiPS = connection.prepareStatement("SELECT nickname FROM galleriafotograficacondivisa.galleriacondivisa NATURAL JOIN galleriafotograficacondivisa.partecipazione NATURAL JOIN galleriafotograficacondivisa.utente WHERE nomeGC='" + nomeGC + "'");
            elencoUtenti = recuperoUtentiPartecipantiPS.executeQuery();
        } catch (SQLException e) {
        }
        return elencoUtenti;
    }

    public ResultSet recuperoFotografie(Integer codGC, String nickname){
        PreparedStatement recuperoFotografieGalleriaCondivisaPS;
        ResultSet elencoFoto;
        try {
            recuperoFotografieGalleriaCondivisaPS = connection.prepareStatement("SELECT codfoto, nomefoto, dispositivo, nfotografo, dimaltezza, dimlarghezza, datascatto, nomeluogo, latitudine, longitudine FROM galleriafotograficacondivisa.Foto NATURAL JOIN galleriafotograficacondivisa.Luogo NATURAL JOIN galleriafotograficacondivisa.Condivisione NATURAL JOIN galleriafotograficacondivisa.GalleriaCondivisa WHERE codGC=" + codGC + " AND ElencoUtenti LIKE '%"+nickname+"%'");
            elencoFoto = recuperoFotografieGalleriaCondivisaPS.executeQuery();
        } catch(SQLException e){
            return null;
        }
        return elencoFoto;
    }

    public String recuperoCopertinaGalleriaCondivisa(Integer codGC, String utenteLoggato) {
        PreparedStatement recuperoCopertinaGalleriaCondivisaPS;
        ResultSet fotografia;
        String fotoCopertina= null;
        try {
            recuperoCopertinaGalleriaCondivisaPS = connection.prepareStatement("SELECT nomeFoto,codFoto FROM galleriafotograficacondivisa.galleriacondivisa NATURAL JOIN galleriafotograficacondivisa.condivisione NATURAL JOIN galleriafotograficacondivisa.foto WHERE codGC='" + codGC + "' AND ElencoUtenti LIKE '%"+utenteLoggato+"%' LIMIT 1");
            fotografia = recuperoCopertinaGalleriaCondivisaPS.executeQuery();
            if (fotografia.next())
                fotoCopertina=fotografia.getString(1)+fotografia.getString(2);
        } catch (SQLException e){
        }
        return fotoCopertina;
    }

}
