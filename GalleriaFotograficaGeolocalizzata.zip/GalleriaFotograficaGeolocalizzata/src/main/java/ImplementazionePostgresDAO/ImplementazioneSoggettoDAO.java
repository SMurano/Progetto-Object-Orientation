package ImplementazionePostgresDAO;
import DAO.SoggettoDAO;
import Database.ConnessioneDataBase;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ImplementazioneSoggettoDAO implements SoggettoDAO{
    private Connection connection;

    public ImplementazioneSoggettoDAO() {
        try {
            connection = ConnessioneDataBase.getInstance().connection;
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void inserimentoSoggetto(String nome, String tipo) {
        PreparedStatement inserimentoSoggettoPS = null;
        try {
            if (tipo.equals("utente"))
                inserimentoSoggettoPS = connection.prepareStatement("INSERT INTO galleriafotograficacondivisa.Soggetto VALUES(DEFAULT,'"+tipo+"','"+nome+"')");
            if (tipo.equals("luogo"))
                inserimentoSoggettoPS = connection.prepareStatement("INSERT INTO galleriafotograficacondivisa.Soggetto VALUES(DEFAULT,'"+tipo+"',NULL,'"+nome+"')");
            if (!tipo.equals("luogo") && !tipo.equals("utente"))
                inserimentoSoggettoPS = connection.prepareStatement("INSERT INTO galleriafotograficacondivisa.Soggetto VALUES(DEFAULT,'"+tipo+"')");
            inserimentoSoggettoPS.executeQuery();
        } catch (SQLException e) {
        }
    }
    public void associaSoggettoFotografia(String nome, String tipo, Integer codFoto){
        PreparedStatement associaSoggettoFotografiaPS = null;
        ResultSet codiceSoggetto;
        Integer codSoggetto;
        try {
            if(tipo.equals("utente"))
            associaSoggettoFotografiaPS = connection.prepareStatement("SELECT codSoggetto FROM galleriafotograficacondivisa.Soggetto WHERE tipo='" + tipo + "'AND nickSoggetto='" + nome + "'");
            if(tipo.equals("luogo"))
                associaSoggettoFotografiaPS = connection.prepareStatement("SELECT codSoggetto FROM galleriafotograficacondivisa.Soggetto WHERE tipo='" + tipo + "'AND nomeSoggetto='" + nome + "'");
            if (!tipo.equals("utente") && !tipo.equals("luogo"))
                associaSoggettoFotografiaPS = connection.prepareStatement("SELECT codSoggetto FROM galleriafotograficacondivisa.Soggetto WHERE tipo='" + tipo + "'");
            codiceSoggetto = associaSoggettoFotografiaPS.executeQuery();
            if (codiceSoggetto.next()) {
                codSoggetto= codiceSoggetto.getInt(1);
                associaSoggettoFotografiaPS = connection.prepareStatement("INSERT INTO galleriafotograficacondivisa.Afferenza VALUES('" + codFoto + "','" + codSoggetto + "')");
                codiceSoggetto = associaSoggettoFotografiaPS.executeQuery();
            }
        } catch (SQLException e) {
        }
    }

    @Override
    public Boolean controlloEsistenzaSoggetto(String nome, String tipo) {
        PreparedStatement controlloEsistenzaSoggettoPS=null;
        ResultSet codiceSoggetto;
        try {
            if(tipo.equals("utente"))
                controlloEsistenzaSoggettoPS = connection.prepareStatement("SELECT codSoggetto FROM galleriafotograficacondivisa.Soggetto WHERE tipo='"+tipo+"'AND nickSoggetto='"+nome+"'");
            if(tipo.equals("luogo"))
            controlloEsistenzaSoggettoPS = connection.prepareStatement("SELECT codSoggetto FROM galleriafotograficacondivisa.Soggetto WHERE tipo='"+tipo+"'AND nomeSoggetto='"+nome+"'");
            if(!tipo.equals("utente") && !tipo.equals("luogo"))
                controlloEsistenzaSoggettoPS = connection.prepareStatement("SELECT codSoggetto FROM galleriafotograficacondivisa.Soggetto WHERE tipo='"+tipo+"'");
            codiceSoggetto= controlloEsistenzaSoggettoPS.executeQuery();
            if (codiceSoggetto.next())
                return true;
            else
                return false;
        } catch (SQLException e) {
            return false;
        }
    }

    public ResultSet recuperoSoggettiFotografia(Integer codFoto){
        PreparedStatement recuperoSoggettiFotografiaPS;
        ResultSet elencoSoggetti=null;
        try {
            recuperoSoggettiFotografiaPS = connection.prepareStatement("SELECT codSoggetto,tipo,nickSoggetto,nomeSoggetto FROM galleriafotograficacondivisa.Foto NATURAL JOIN galleriafotograficacondivisa.Afferenza NATURAL JOIN galleriafotograficacondivisa.Soggetto  WHERE CodFoto=" + codFoto);
            elencoSoggetti = recuperoSoggettiFotografiaPS.executeQuery();
        } catch (SQLException e){
            return null;
        }
        return  elencoSoggetti;
    }

    public ResultSet top3LuoghiImmortalati(){
        PreparedStatement top3LuoghiImmortalatiPS;
        ResultSet luoghi = null;
        try {
            top3LuoghiImmortalatiPS=connection.prepareStatement("SELECT nomeSoggetto FROM galleriafotograficacondivisa.top3luoghi");
            luoghi=top3LuoghiImmortalatiPS.executeQuery();
        } catch (SQLException e) {
        }
        return luoghi;
    }
}
