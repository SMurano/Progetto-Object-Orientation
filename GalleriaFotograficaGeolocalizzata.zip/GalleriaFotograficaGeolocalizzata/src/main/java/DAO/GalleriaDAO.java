package DAO;

import Model.Galleria;
import Model.GalleriaPersonale;
import Model.Utente;

import java.sql.ResultSet;

public interface GalleriaDAO {
    Integer associaCodiceGalleria(String nomeGalleria);
    void inserimentoFotografiaInGalleria(Integer codFoto, Integer codG);
    ResultSet recuperoFotografie(String nickname);
    void rimuoviFotografiaDaGalleria(Integer codFoto, Integer codG);

}
