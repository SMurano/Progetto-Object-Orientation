package DAO;

public interface SoggettoDAO {
    void inserimentoSoggetto(String nome, String tipo);
    Boolean controlloEsistenzaSoggetto(String nome, String tipo);
    void associaSoggettoFotografia(String nome, String tipo, Integer codFoto);
}
