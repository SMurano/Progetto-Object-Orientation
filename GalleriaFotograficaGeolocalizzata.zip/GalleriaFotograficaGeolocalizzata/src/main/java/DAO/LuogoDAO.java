package DAO;

import Model.Luogo;
import Controller.Controller;

public interface LuogoDAO {
    Integer controlloEsistenzaLuogo(String nome, Double latitudine, Double longitudine, Controller controller);
    void inserimentoLuogo(Double latitudine, Double longitudine, String nome);

}
