package DAO;

import Model.Fotografia;

import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

public interface FotografiaDAO {

    void inserimentoFoto(String dispositivo, Integer altezza, Integer larghezza, String nome, String fotografo, String nomeLuogo, String visibilita, Date data);
    Integer associaCodiceFoto();
    ResultSet recuperoSoggettiFoto(String nickname, Integer codFoto);
    void rendiFotoPubblica(Integer codFoto);
    void privatizzaFoto(Integer codFoto);
    }

