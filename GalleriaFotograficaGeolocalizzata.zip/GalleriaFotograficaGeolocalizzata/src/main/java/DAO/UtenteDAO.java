package DAO;
import Model.GalleriaCondivisa;
import Model.Utente;

import java.util.ArrayList;

public interface UtenteDAO {
     Boolean controlloEsistenzaUtente(String nickname, String password);
     Boolean registrazioneUtente(String nome, String cognome,String nickname, String password);
     ArrayList<String> recuperoGallerieACuiPartecipi(String nickname);

}
